# Tarot Meiga - TODO

## Base y configuración
- [x] Subir imágenes a S3 y reemplazar rutas locales
- [x] Esquema de base de datos (reservas, conversaciones chat)
- [x] Backend tRPC: procedimientos para chat IA, reservas, tarotistas
- [x] CSS temático oscuro místico (morado, dorado, negro)

## Páginas y componentes
- [x] Página principal (Home) con hero, galería 45 tarotistas, sección Reina
- [x] Galería de 45 tarotistas IA con nombre, especialidad, avatar y personalidad
- [x] Página individual de cada tarotista (/tarotista/:id)
- [x] Chat IA por tarotista con límite de 1 pregunta gratis (localStorage)
- [x] Sección Reina con foto, bio y botón de reserva
- [x] Formulario de reservas para Reina (nombre, tipo consulta, método contacto, mensaje)
- [x] Header con logo, navegación y datos de contacto
- [x] Footer con contacto (+34 625815306, tarotmeiga.es@gmail.com)

## Funcionalidades
- [x] Sistema de límite de pregunta gratis por tarotista (localStorage)
- [x] Notificación al owner cuando llega una reserva nueva
- [x] Diseño responsive móvil y desktop
- [x] Navegación intuitiva entre páginas

## Tests
- [x] Tests vitest para procedimientos de reservas
- [x] Tests vitest para procedimiento de chat IA

## Mejoras visuales
- [x] Generar e integrar fotos reales (IA) para las 45 tarotistas (retratos únicos subidos a S3)
- [x] Reemplazar emojis/avatares por imágenes fotorrealistas en cards y página individual

## Nuevas funcionalidades (fase 2)
- [x] Panel de administración para Reina (ver/gestionar reservas, cambiar estado)
- [x] Registro y listado de clientes en panel admin
- [x] Sección de precios y bonos visible en la web
- [x] Panel de recarga de saldo/bonos para clientes
- [x] Formulario "Trabaja con Nosotros" para tarotistas
- [x] Aviso de cookies con aceptación/rechazo
- [x] Página de Términos Legales y Política de Privacidad
- [x] Chatbot IA de atención al cliente (flotante) - Luna
- [x] Botón flotante de WhatsApp para soporte/dudas

## Fase 3 - Mejoras y duplicación
- [ ] Reparar fotos de tarotistas que no cargan
- [ ] Integrar Stripe para pago de bonos (sin Bizum)
- [ ] Sistema de reseñas y testimonios de clientes
- [ ] Duplicar web como "Tarot Reina" (mismo código, mismas fotos)
