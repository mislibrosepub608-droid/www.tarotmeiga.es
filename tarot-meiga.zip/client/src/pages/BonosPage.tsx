import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Star, Zap, Crown, Package, CreditCard, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";
import { BONOS_STRIPE } from "../../../server/stripeProducts";

const S = {
  bg: "oklch(0.10 0.02 280)",
  card: { background: "oklch(0.14 0.03 280)", border: "1px solid oklch(0.25 0.06 280)", borderRadius: "0.75rem", padding: "1.5rem", position: "relative" as const, overflow: "hidden" as const },
  gold: "oklch(0.72 0.15 65)",
  goldLight: "oklch(0.85 0.12 65)",
  muted: "oklch(0.65 0.05 60)",
  text: "oklch(0.92 0.04 60)",
  input: { background: "oklch(0.18 0.04 280)", border: "1px solid oklch(0.30 0.06 280)", color: "oklch(0.92 0.04 60)", padding: "0.75rem 1rem", borderRadius: "0.5rem", fontFamily: "Georgia, serif", fontSize: "0.9rem", width: "100%", boxSizing: "border-box" as const },
  btn: { background: "linear-gradient(135deg, oklch(0.65 0.18 55), oklch(0.72 0.15 65))", color: "oklch(0.10 0.02 280)", border: "none", padding: "0.85rem 2rem", borderRadius: "0.5rem", cursor: "pointer", fontFamily: "'Cinzel', serif", fontSize: "0.85rem", fontWeight: "700", letterSpacing: "0.05em", width: "100%" },
};

const bonoIcons = [<Zap size={22} />, <Star size={22} />, <Package size={22} />, <Crown size={22} />, <CreditCard size={22} />, <CreditCard size={22} />];
const bonoColors = ["oklch(0.65 0.18 200)", "oklch(0.72 0.15 65)", "oklch(0.65 0.18 145)", "oklch(0.75 0.15 310)", "oklch(0.65 0.15 25)", "oklch(0.65 0.15 25)"];

export default function BonosPage() {
  const checkoutMutation = trpc.pagos.crearCheckout.useMutation();

  const [selectedBono, setSelectedBono] = useState<typeof BONOS_STRIPE[0] | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [pagoEstado, setPagoEstado] = useState<"exitoso" | "cancelado" | null>(null);
  const [form, setForm] = useState({ clienteNombre: "", clienteEmail: "" });

  // Detectar retorno de Stripe
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const pago = params.get("pago");
    if (pago === "exitoso") {
      setPagoEstado("exitoso");
      window.history.replaceState({}, "", "/bonos");
    } else if (pago === "cancelado") {
      setPagoEstado("cancelado");
      window.history.replaceState({}, "", "/bonos");
    }
  }, []);

  const handleSelectBono = (bono: typeof BONOS_STRIPE[0]) => {
    setSelectedBono(bono);
    setShowForm(true);
    setPagoEstado(null);
    setTimeout(() => {
      document.getElementById("formulario-pago")?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  const handlePagar = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBono) return;
    try {
      toast.info("Redirigiendo al pago seguro...");
      const result = await checkoutMutation.mutateAsync({
        bonoId: selectedBono.id,
        clienteNombre: form.clienteNombre || undefined,
        clienteEmail: form.clienteEmail || undefined,
        origin: window.location.origin,
      });
      if (result.url) {
        window.open(result.url, "_blank");
      }
    } catch (err) {
      toast.error("Error al procesar el pago. Por favor, inténtalo de nuevo.");
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: S.bg }}>
      <Header />

      {/* Hero */}
      <section style={{ padding: "4rem 0 2rem", textAlign: "center", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(ellipse at 50% 0%, oklch(0.25 0.10 290 / 0.4) 0%, transparent 60%)", pointerEvents: "none" }} />
        <div className="container" style={{ position: "relative" }}>
          <p style={{ color: S.gold, fontSize: "0.8rem", letterSpacing: "0.3em", textTransform: "uppercase", fontFamily: "'Cinzel', serif", marginBottom: "0.75rem" }}>✦ Tarot Meiga ✦</p>
          <h1 className="gradient-gold" style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: "900", marginBottom: "1rem", letterSpacing: "0.1em" }}>
            Bonos & Precios
          </h1>
          <p style={{ color: S.muted, maxWidth: "600px", margin: "0 auto", fontFamily: "Georgia, serif", lineHeight: 1.8, fontSize: "1rem" }}>
            Elige el bono que mejor se adapte a tus necesidades espirituales. Pago 100% seguro con tarjeta a través de Stripe.
          </p>
        </div>
      </section>

      <hr className="divider-gold" style={{ margin: "0" }} />

      {/* Estado de pago */}
      {pagoEstado === "exitoso" && (
        <div className="container" style={{ padding: "2rem 1rem 0" }}>
          <div style={{ ...S.card, textAlign: "center", padding: "2rem", background: "oklch(0.12 0.05 145 / 0.8)", border: "1px solid oklch(0.65 0.18 145 / 0.5)" }}>
            <CheckCircle size={40} style={{ color: "oklch(0.65 0.18 145)", margin: "0 auto 1rem" }} />
            <h3 style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontSize: "1.2rem", marginBottom: "0.5rem" }}>¡Pago Completado con Éxito!</h3>
            <p style={{ color: S.muted, fontFamily: "Georgia, serif" }}>Reina se pondrá en contacto contigo en breve para activar tu bono. Revisa tu email.</p>
            <p style={{ color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.85rem", marginTop: "0.75rem" }}>📞 +34 625 815 306 · 📧 tarotmeiga.es@gmail.com</p>
          </div>
        </div>
      )}

      {pagoEstado === "cancelado" && (
        <div className="container" style={{ padding: "2rem 1rem 0" }}>
          <div style={{ ...S.card, textAlign: "center", padding: "2rem", background: "oklch(0.12 0.05 25 / 0.8)", border: "1px solid oklch(0.65 0.15 25 / 0.5)" }}>
            <XCircle size={40} style={{ color: "oklch(0.65 0.15 25)", margin: "0 auto 1rem" }} />
            <h3 style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontSize: "1.2rem", marginBottom: "0.5rem" }}>Pago Cancelado</h3>
            <p style={{ color: S.muted, fontFamily: "Georgia, serif" }}>No se ha realizado ningún cargo. Puedes intentarlo de nuevo cuando quieras.</p>
          </div>
        </div>
      )}

      {/* Bonos */}
      <section style={{ padding: "4rem 0" }}>
        <div className="container">
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "1.5rem" }}>
            {BONOS_STRIPE.map((bono, i) => {
              const color = bonoColors[i % bonoColors.length];
              const isPopular = bono.popular;
              return (
                <div key={bono.id} style={{ ...S.card, border: isPopular ? `1px solid ${S.gold}` : S.card.border, transform: isPopular ? "scale(1.02)" : "none", transition: "transform 0.3s ease" }}>
                  <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: `linear-gradient(90deg, transparent, ${color}, transparent)` }} />
                  {isPopular && (
                    <div style={{ position: "absolute", top: "0.75rem", right: "0.75rem", background: `linear-gradient(135deg, ${S.gold}, oklch(0.85 0.12 65))`, color: "oklch(0.10 0.02 280)", padding: "0.2rem 0.7rem", borderRadius: "9999px", fontSize: "0.65rem", fontFamily: "'Cinzel', serif", fontWeight: "700" }}>
                      ✦ MÁS POPULAR
                    </div>
                  )}

                  <div style={{ color, marginBottom: "1rem", display: "flex", alignItems: "center", gap: "0.75rem" }}>
                    {bonoIcons[i % bonoIcons.length]}
                    <h3 style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontWeight: "700", fontSize: "1.05rem" }}>{bono.nombre}</h3>
                  </div>

                  <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.88rem", lineHeight: 1.6, marginBottom: "1.25rem" }}>{bono.descripcion}</p>

                  <div style={{ display: "flex", alignItems: "baseline", gap: "0.4rem", marginBottom: "0.5rem" }}>
                    <span style={{ fontFamily: "'Cinzel', serif", color: S.gold, fontWeight: "900", fontSize: "2.2rem" }}>{(bono.precio / 100).toFixed(2)}€</span>
                  </div>

                  <div style={{ display: "flex", alignItems: "center", gap: "0.4rem", marginBottom: "1.5rem" }}>
                    <span style={{ background: `${color}22`, border: `1px solid ${color}55`, color, padding: "0.25rem 0.75rem", borderRadius: "9999px", fontSize: "0.75rem", fontFamily: "'Cinzel', serif" }}>
                      {bono.creditos} {bono.tipo}
                    </span>
                  </div>

                  <button
                    onClick={() => handleSelectBono(bono)}
                    style={{ ...S.btn, background: isPopular ? `linear-gradient(135deg, ${S.gold}, oklch(0.85 0.12 65))` : `linear-gradient(135deg, ${color}33, ${color}55)`, color: isPopular ? "oklch(0.10 0.02 280)" : color, border: isPopular ? "none" : `1px solid ${color}66` }}
                  >
                    {isPopular ? "✦ Elegir Este Bono" : "Seleccionar"}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Formulario de pago Stripe */}
      <section id="formulario-pago" style={{ padding: "0 0 5rem" }}>
        <div className="container" style={{ maxWidth: "560px" }}>
          {showForm && selectedBono && (
            <div style={S.card}>
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: "linear-gradient(90deg, transparent, oklch(0.72 0.15 65), transparent)" }} />
              <h2 style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontSize: "1.2rem", fontWeight: "700", marginBottom: "0.5rem" }}>
                Pago Seguro con Tarjeta
              </h2>

              <div style={{ background: "oklch(0.65 0.18 55 / 0.1)", border: "1px solid oklch(0.72 0.15 65 / 0.3)", borderRadius: "0.5rem", padding: "0.75rem 1rem", marginBottom: "1.5rem" }}>
                <p style={{ color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.9rem", fontWeight: "700" }}>{selectedBono.nombre} — {(selectedBono.precio / 100).toFixed(2)}€</p>
                <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.8rem" }}>{selectedBono.descripcion}</p>
              </div>

              <form onSubmit={handlePagar} style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                <div>
                  <label style={{ display: "block", color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.78rem", marginBottom: "0.4rem", letterSpacing: "0.05em" }}>NOMBRE (OPCIONAL)</label>
                  <input value={form.clienteNombre} onChange={e => setForm(f => ({ ...f, clienteNombre: e.target.value }))} placeholder="Tu nombre" style={S.input} />
                </div>
                <div>
                  <label style={{ display: "block", color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.78rem", marginBottom: "0.4rem", letterSpacing: "0.05em" }}>EMAIL (OPCIONAL)</label>
                  <input type="email" value={form.clienteEmail} onChange={e => setForm(f => ({ ...f, clienteEmail: e.target.value }))} placeholder="tu@email.com" style={S.input} />
                </div>

                <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.8rem", lineHeight: 1.6 }}>
                  🔒 Serás redirigido a la pasarela de pago seguro de Stripe. Una vez completado el pago, Reina activará tu bono.
                </p>

                <div style={{ display: "flex", gap: "0.75rem" }}>
                  <button type="submit" style={S.btn} disabled={checkoutMutation.isPending}>
                    {checkoutMutation.isPending ? "Procesando..." : "💳 Pagar Ahora con Stripe"}
                  </button>
                  <button type="button" onClick={() => { setShowForm(false); setSelectedBono(null); }} style={{ ...S.btn, background: "transparent", border: "1px solid oklch(0.30 0.06 280)", color: S.muted, flex: "0 0 auto", width: "auto", padding: "0.85rem 1.5rem" }}>
                    Cancelar
                  </button>
                </div>
              </form>
            </div>
          )}

          {!showForm && !pagoEstado && (
            <div style={{ textAlign: "center", padding: "2rem" }}>
              <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.9rem" }}>
                Selecciona un bono arriba para proceder al pago seguro con tarjeta.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Info de prueba */}
      <section style={{ padding: "0 0 4rem" }}>
        <div className="container" style={{ maxWidth: "600px" }}>
          <div style={{ ...S.card, textAlign: "center", background: "oklch(0.12 0.04 290 / 0.6)" }}>
            <p style={{ color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.85rem", fontWeight: "700", marginBottom: "0.5rem" }}>🔒 Pago 100% Seguro</p>
            <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.82rem", lineHeight: 1.7 }}>
              Todos los pagos se procesan a través de Stripe, la plataforma de pagos más segura del mundo. Tus datos bancarios nunca son almacenados en nuestros servidores.
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
