import { useState } from "react";
import { trpc } from "@/lib/trpc";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Users, Calendar, Package, Briefcase, RefreshCw, CheckCircle, XCircle, Clock, ChevronDown } from "lucide-react";

const ADMIN_PASSWORD = "reina2024";

const S = {
  bg: "oklch(0.10 0.02 280)",
  card: { background: "oklch(0.14 0.03 280)", border: "1px solid oklch(0.25 0.06 280)", borderRadius: "0.75rem", padding: "1.5rem", position: "relative" as const, overflow: "hidden" as const },
  gold: "oklch(0.72 0.15 65)",
  goldLight: "oklch(0.85 0.12 65)",
  muted: "oklch(0.65 0.05 60)",
  text: "oklch(0.92 0.04 60)",
  badge: (color: string) => ({ display: "inline-flex", alignItems: "center" as const, gap: "0.3rem", padding: "0.2rem 0.7rem", borderRadius: "9999px", fontSize: "0.72rem", fontFamily: "'Cinzel', serif", background: `${color}22`, border: `1px solid ${color}66`, color }),
  btn: { background: "linear-gradient(135deg, oklch(0.65 0.18 55), oklch(0.72 0.15 65))", color: "oklch(0.10 0.02 280)", border: "none", padding: "0.5rem 1.2rem", borderRadius: "0.4rem", cursor: "pointer", fontFamily: "'Cinzel', serif", fontSize: "0.78rem", fontWeight: "700" },
  btnSm: (color: string) => ({ background: `${color}22`, border: `1px solid ${color}66`, color, padding: "0.3rem 0.8rem", borderRadius: "0.35rem", cursor: "pointer", fontSize: "0.72rem", fontFamily: "'Cinzel', serif" }),
  input: { background: "oklch(0.18 0.04 280)", border: "1px solid oklch(0.30 0.06 280)", color: "oklch(0.92 0.04 60)", padding: "0.6rem 0.9rem", borderRadius: "0.4rem", fontFamily: "Georgia, serif", fontSize: "0.9rem", width: "100%" },
  select: { background: "oklch(0.18 0.04 280)", border: "1px solid oklch(0.30 0.06 280)", color: "oklch(0.92 0.04 60)", padding: "0.5rem 0.8rem", borderRadius: "0.4rem", fontFamily: "Georgia, serif", fontSize: "0.85rem" },
  tab: (active: boolean) => ({ padding: "0.6rem 1.2rem", borderRadius: "0.4rem 0.4rem 0 0", cursor: "pointer", fontFamily: "'Cinzel', serif", fontSize: "0.78rem", fontWeight: active ? "700" : "400", background: active ? "oklch(0.65 0.18 55 / 0.2)" : "transparent", color: active ? "oklch(0.85 0.12 65)" : "oklch(0.55 0.05 60)", border: "none", borderBottom: active ? "2px solid oklch(0.72 0.15 65)" : "2px solid transparent", transition: "all 0.2s" }),
};

const estadoColor: Record<string, string> = {
  pendiente: "oklch(0.75 0.15 65)",
  confirmada: "oklch(0.65 0.18 145)",
  completada: "oklch(0.60 0.15 200)",
  cancelada: "oklch(0.55 0.18 25)",
  rechazada: "oklch(0.55 0.18 25)",
  revisada: "oklch(0.65 0.15 200)",
  aceptada: "oklch(0.65 0.18 145)",
  activo: "oklch(0.65 0.18 145)",
  inactivo: "oklch(0.55 0.05 60)",
  si: "oklch(0.65 0.18 145)",
  no: "oklch(0.55 0.05 60)",
};

function LoginPanel({ onLogin }: { onLogin: () => void }) {
  const [pwd, setPwd] = useState("");
  const [error, setError] = useState(false);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pwd === ADMIN_PASSWORD) { onLogin(); }
    else { setError(true); setTimeout(() => setError(false), 2000); }
  };
  return (
    <div style={{ minHeight: "100vh", background: S.bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ ...S.card, maxWidth: "380px", width: "100%", textAlign: "center" }}>
        <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>🔐</div>
        <h2 style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontSize: "1.4rem", marginBottom: "0.5rem" }}>Panel de Reina</h2>
        <p style={{ color: S.muted, fontSize: "0.85rem", marginBottom: "1.5rem", fontFamily: "Georgia, serif" }}>Acceso exclusivo para administración</p>
        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
          <input type="password" placeholder="Contraseña" value={pwd} onChange={e => setPwd(e.target.value)} style={{ ...S.input, textAlign: "center" }} />
          {error && <p style={{ color: "oklch(0.65 0.18 25)", fontSize: "0.8rem", fontFamily: "Georgia, serif" }}>Contraseña incorrecta</p>}
          <button type="submit" style={S.btn}>Entrar al Panel ✦</button>
        </form>
      </div>
    </div>
  );
}

function ReservasTab() {
  const { data: reservas, refetch } = trpc.reservas.listar.useQuery();
  const updateMutation = trpc.reservas.actualizarEstado.useMutation({ onSuccess: () => refetch() });
  const [filter, setFilter] = useState("todas");

  const filtered = reservas?.filter(r => filter === "todas" || r.estado === filter) ?? [];

  return (
    <div>
      <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1.5rem", flexWrap: "wrap" }}>
        {["todas", "pendiente", "confirmada", "completada", "cancelada"].map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{ ...S.btnSm(filter === f ? S.gold : S.muted), textTransform: "capitalize" }}>{f}</button>
        ))}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
        {filtered.length === 0 && <p style={{ color: S.muted, fontFamily: "Georgia, serif", textAlign: "center", padding: "2rem" }}>No hay reservas {filter !== "todas" ? `con estado "${filter}"` : "aún"}.</p>}
        {filtered.map(r => (
          <div key={r.id} style={{ ...S.card, padding: "1.25rem" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "0.75rem" }}>
              <div>
                <p style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontWeight: "700", fontSize: "1rem", marginBottom: "0.25rem" }}>{r.nombre}</p>
                <p style={{ color: S.muted, fontSize: "0.8rem", fontFamily: "Georgia, serif" }}>
                  {r.email && <span>{r.email} · </span>}
                  {r.telefono && <span>{r.telefono} · </span>}
                  <span style={{ textTransform: "capitalize" }}>{r.tipoConsulta}</span> · <span style={{ textTransform: "capitalize" }}>{r.metodoContacto}</span>
                </p>
                {r.mensaje && <p style={{ color: S.text, fontSize: "0.85rem", fontFamily: "Georgia, serif", marginTop: "0.5rem", fontStyle: "italic" }}>"{r.mensaje}"</p>}
                <p style={{ color: S.muted, fontSize: "0.72rem", fontFamily: "Georgia, serif", marginTop: "0.4rem" }}>{new Date(r.createdAt).toLocaleString("es-ES")}</p>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "0.5rem" }}>
                <span style={S.badge(estadoColor[r.estado] ?? S.muted)}>{r.estado}</span>
                <select
                  value={r.estado}
                  onChange={e => updateMutation.mutate({ id: r.id, estado: e.target.value as any })}
                  style={{ ...S.select, fontSize: "0.75rem" }}
                >
                  {["pendiente", "confirmada", "completada", "cancelada"].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ClientesTab() {
  const { data: clientes, refetch } = trpc.clientes.listar.useQuery();
  const crearMutation = trpc.clientes.crear.useMutation({ onSuccess: () => { refetch(); setForm({ nombre: "", email: "", telefono: "", notas: "" }); setShowForm(false); } });
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ nombre: "", email: "", telefono: "", notas: "" });
  const [editNotas, setEditNotas] = useState<number | null>(null);
  const [notasVal, setNotasVal] = useState("");
  const notasMutation = trpc.clientes.actualizarNotas.useMutation({ onSuccess: () => { refetch(); setEditNotas(null); } });

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1.5rem" }}>
        <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.85rem" }}>{clientes?.length ?? 0} clientes registrados</p>
        <button onClick={() => setShowForm(!showForm)} style={S.btn}>+ Añadir Cliente</button>
      </div>

      {showForm && (
        <div style={{ ...S.card, marginBottom: "1.5rem" }}>
          <h3 style={{ fontFamily: "'Cinzel', serif", color: S.gold, marginBottom: "1rem", fontSize: "0.95rem" }}>Nuevo Cliente</h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "0.75rem" }}>
            <input placeholder="Nombre *" value={form.nombre} onChange={e => setForm(f => ({ ...f, nombre: e.target.value }))} style={S.input} />
            <input placeholder="Email *" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} style={S.input} />
            <input placeholder="Teléfono" value={form.telefono} onChange={e => setForm(f => ({ ...f, telefono: e.target.value }))} style={S.input} />
            <input placeholder="Notas" value={form.notas} onChange={e => setForm(f => ({ ...f, notas: e.target.value }))} style={S.input} />
          </div>
          <div style={{ display: "flex", gap: "0.75rem", marginTop: "1rem" }}>
            <button onClick={() => crearMutation.mutate(form)} style={S.btn} disabled={!form.nombre || !form.email}>Guardar</button>
            <button onClick={() => setShowForm(false)} style={S.btnSm(S.muted)}>Cancelar</button>
          </div>
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
        {(clientes ?? []).map(c => (
          <div key={c.id} style={{ ...S.card, padding: "1.25rem" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "0.75rem" }}>
              <div>
                <p style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontWeight: "700", fontSize: "0.95rem" }}>{c.nombre}</p>
                <p style={{ color: S.muted, fontSize: "0.8rem", fontFamily: "Georgia, serif" }}>{c.email}{c.telefono ? ` · ${c.telefono}` : ""}</p>
                {editNotas === c.id ? (
                  <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.5rem" }}>
                    <input value={notasVal} onChange={e => setNotasVal(e.target.value)} style={{ ...S.input, fontSize: "0.8rem" }} placeholder="Notas..." />
                    <button onClick={() => notasMutation.mutate({ id: c.id, notas: notasVal })} style={S.btnSm("oklch(0.65 0.18 145)")}>✓</button>
                    <button onClick={() => setEditNotas(null)} style={S.btnSm(S.muted)}>✕</button>
                  </div>
                ) : (
                  <p style={{ color: S.text, fontSize: "0.8rem", fontFamily: "Georgia, serif", marginTop: "0.3rem", cursor: "pointer" }} onClick={() => { setEditNotas(c.id); setNotasVal(c.notas ?? ""); }}>
                    {c.notas ? `📝 ${c.notas}` : <span style={{ color: S.muted }}>+ Añadir notas</span>}
                  </p>
                )}
              </div>
              <div style={{ textAlign: "right" }}>
                <p style={{ color: S.gold, fontFamily: "'Cinzel', serif", fontWeight: "700", fontSize: "1.1rem" }}>{c.saldo}€</p>
                <p style={{ color: S.muted, fontSize: "0.72rem" }}>saldo</p>
                <p style={{ color: S.muted, fontSize: "0.72rem", marginTop: "0.25rem" }}>{new Date(c.createdAt).toLocaleDateString("es-ES")}</p>
              </div>
            </div>
          </div>
        ))}
        {(clientes ?? []).length === 0 && <p style={{ color: S.muted, fontFamily: "Georgia, serif", textAlign: "center", padding: "2rem" }}>No hay clientes registrados aún.</p>}
      </div>
    </div>
  );
}

function BonosTab() {
  const { data: bonos, refetch } = trpc.bonos.listar.useQuery();
  const { data: recargas, refetch: refetchRecargas } = trpc.recargas.listar.useQuery();
  const updateRecarga = trpc.recargas.actualizarEstado.useMutation({ onSuccess: () => refetchRecargas() });
  const [subTab, setSubTab] = useState<"bonos" | "recargas">("bonos");

  return (
    <div>
      <div style={{ display: "flex", gap: "0.5rem", marginBottom: "1.5rem" }}>
        <button onClick={() => setSubTab("bonos")} style={S.tab(subTab === "bonos")}>Bonos Disponibles</button>
        <button onClick={() => setSubTab("recargas")} style={S.tab(subTab === "recargas")}>Solicitudes de Recarga</button>
      </div>

      {subTab === "bonos" && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: "1rem" }}>
          {(bonos ?? []).map(b => (
            <div key={b.id} style={{ ...S.card, padding: "1.25rem" }}>
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: "linear-gradient(90deg, transparent, oklch(0.72 0.15 65), transparent)" }} />
              <p style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontWeight: "700", fontSize: "0.95rem", marginBottom: "0.4rem" }}>{b.nombre}</p>
              <p style={{ color: S.muted, fontSize: "0.8rem", fontFamily: "Georgia, serif", marginBottom: "0.75rem" }}>{b.descripcion}</p>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ color: S.gold, fontFamily: "'Cinzel', serif", fontWeight: "700", fontSize: "1.3rem" }}>{b.precio}€</span>
                <span style={S.badge(S.gold)}>{b.creditos} {b.tipo}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {subTab === "recargas" && (
        <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
          {(recargas ?? []).length === 0 && <p style={{ color: S.muted, fontFamily: "Georgia, serif", textAlign: "center", padding: "2rem" }}>No hay solicitudes de recarga aún.</p>}
          {(recargas ?? []).map(r => (
            <div key={r.id} style={{ ...S.card, padding: "1.25rem" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "0.75rem" }}>
                <div>
                  <p style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontWeight: "700", fontSize: "0.95rem" }}>{r.clienteNombre}</p>
                  <p style={{ color: S.muted, fontSize: "0.8rem", fontFamily: "Georgia, serif" }}>{r.clienteEmail}{r.clienteTelefono ? ` · ${r.clienteTelefono}` : ""}</p>
                  <p style={{ color: S.text, fontSize: "0.85rem", fontFamily: "Georgia, serif", marginTop: "0.4rem" }}>Bono: <strong>{r.bonoNombre}</strong> · Método: {r.metodo}</p>
                  <p style={{ color: S.muted, fontSize: "0.72rem", marginTop: "0.25rem" }}>{new Date(r.createdAt).toLocaleString("es-ES")}</p>
                </div>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "0.5rem" }}>
                  <span style={{ color: S.gold, fontFamily: "'Cinzel', serif", fontWeight: "700", fontSize: "1.1rem" }}>{r.importe}€</span>
                  <span style={S.badge(estadoColor[r.estado] ?? S.muted)}>{r.estado}</span>
                  <select value={r.estado} onChange={e => updateRecarga.mutate({ id: r.id, estado: e.target.value as any })} style={{ ...S.select, fontSize: "0.75rem" }}>
                    {["pendiente", "confirmada", "rechazada"].map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function TrabajoTab() {
  const { data: solicitudes, refetch } = trpc.trabajo.listar.useQuery();
  const updateMutation = trpc.trabajo.actualizarEstado.useMutation({ onSuccess: () => refetch() });
  const [expanded, setExpanded] = useState<number | null>(null);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
      {(solicitudes ?? []).length === 0 && <p style={{ color: S.muted, fontFamily: "Georgia, serif", textAlign: "center", padding: "2rem" }}>No hay solicitudes de trabajo aún.</p>}
      {(solicitudes ?? []).map(s => (
        <div key={s.id} style={{ ...S.card, padding: "1.25rem" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: "0.75rem" }}>
            <div style={{ flex: 1 }}>
              <p style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontWeight: "700", fontSize: "0.95rem" }}>{s.nombre}</p>
              <p style={{ color: S.muted, fontSize: "0.8rem", fontFamily: "Georgia, serif" }}>{s.email}{s.telefono ? ` · ${s.telefono}` : ""}</p>
              <p style={{ color: S.gold, fontSize: "0.82rem", fontFamily: "'Cinzel', serif", marginTop: "0.3rem" }}>Especialidad: {s.especialidad}</p>
              {expanded === s.id && (
                <div style={{ marginTop: "0.75rem", borderTop: "1px solid oklch(0.25 0.06 280)", paddingTop: "0.75rem" }}>
                  <p style={{ color: S.text, fontSize: "0.82rem", fontFamily: "Georgia, serif", marginBottom: "0.5rem" }}><strong style={{ color: S.gold }}>Experiencia:</strong> {s.experiencia}</p>
                  <p style={{ color: S.text, fontSize: "0.82rem", fontFamily: "Georgia, serif", marginBottom: "0.5rem" }}><strong style={{ color: S.gold }}>Presentación:</strong> {s.presentacion}</p>
                  {s.redesSociales && <p style={{ color: S.muted, fontSize: "0.78rem", fontFamily: "Georgia, serif" }}>Redes: {s.redesSociales}</p>}
                </div>
              )}
              <button onClick={() => setExpanded(expanded === s.id ? null : s.id)} style={{ ...S.btnSm(S.muted), marginTop: "0.5rem", display: "flex", alignItems: "center", gap: "0.3rem" }}>
                {expanded === s.id ? "Ver menos" : "Ver más"} <ChevronDown size={12} style={{ transform: expanded === s.id ? "rotate(180deg)" : "none", transition: "0.2s" }} />
              </button>
            </div>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: "0.5rem" }}>
              <span style={S.badge(estadoColor[s.estado] ?? S.muted)}>{s.estado}</span>
              <select value={s.estado} onChange={e => updateMutation.mutate({ id: s.id, estado: e.target.value as any })} style={{ ...S.select, fontSize: "0.75rem" }}>
                {["pendiente", "revisada", "aceptada", "rechazada"].map(st => <option key={st} value={st}>{st}</option>)}
              </select>
              <p style={{ color: S.muted, fontSize: "0.72rem" }}>{new Date(s.createdAt).toLocaleDateString("es-ES")}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState<"reservas" | "clientes" | "bonos" | "trabajo">("reservas");

  const { data: reservas } = trpc.reservas.listar.useQuery(undefined, { enabled: isAuthenticated });
  const { data: clientes } = trpc.clientes.listar.useQuery(undefined, { enabled: isAuthenticated });
  const { data: recargas } = trpc.recargas.listar.useQuery(undefined, { enabled: isAuthenticated });
  const { data: solicitudes } = trpc.trabajo.listar.useQuery(undefined, { enabled: isAuthenticated });

  if (!isAuthenticated) return <LoginPanel onLogin={() => setIsAuthenticated(true)} />;

  const pendientesReservas = reservas?.filter(r => r.estado === "pendiente").length ?? 0;
  const pendientesRecargas = recargas?.filter(r => r.estado === "pendiente").length ?? 0;
  const pendientesTrabajo = solicitudes?.filter(s => s.estado === "pendiente").length ?? 0;

  const tabs = [
    { id: "reservas" as const, label: "Reservas", icon: <Calendar size={14} />, badge: pendientesReservas },
    { id: "clientes" as const, label: "Clientes", icon: <Users size={14} />, badge: 0 },
    { id: "bonos" as const, label: "Bonos & Recargas", icon: <Package size={14} />, badge: pendientesRecargas },
    { id: "trabajo" as const, label: "Trabaja con Nosotros", icon: <Briefcase size={14} />, badge: pendientesTrabajo },
  ];

  return (
    <div style={{ minHeight: "100vh", background: S.bg }}>
      <Header />
      <div className="container" style={{ padding: "2rem 1rem 4rem" }}>
        {/* Header del panel */}
        <div style={{ marginBottom: "2rem" }}>
          <p style={{ color: S.gold, fontSize: "0.8rem", letterSpacing: "0.3em", textTransform: "uppercase", fontFamily: "'Cinzel', serif", marginBottom: "0.4rem" }}>✦ Acceso Exclusivo ✦</p>
          <h1 style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontSize: "clamp(1.5rem, 3vw, 2.2rem)", fontWeight: "700", marginBottom: "0.5rem" }}>Panel de Reina</h1>
          <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.9rem" }}>Gestión completa de tu plataforma Tarot Meiga</p>
        </div>

        {/* Stats rápidas */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: "1rem", marginBottom: "2rem" }}>
          {[
            { label: "Reservas Totales", value: reservas?.length ?? 0, icon: "📅", color: S.gold },
            { label: "Pendientes", value: pendientesReservas, icon: "⏳", color: "oklch(0.75 0.15 65)" },
            { label: "Clientes", value: clientes?.length ?? 0, icon: "👥", color: "oklch(0.65 0.18 145)" },
            { label: "Recargas Pendientes", value: pendientesRecargas, icon: "💳", color: "oklch(0.65 0.15 200)" },
          ].map(stat => (
            <div key={stat.label} style={{ ...S.card, padding: "1.25rem", textAlign: "center" }}>
              <div style={{ fontSize: "1.8rem", marginBottom: "0.4rem" }}>{stat.icon}</div>
              <p style={{ fontFamily: "'Cinzel', serif", color: stat.color, fontWeight: "700", fontSize: "1.6rem", lineHeight: 1 }}>{stat.value}</p>
              <p style={{ color: S.muted, fontSize: "0.72rem", fontFamily: "Georgia, serif", marginTop: "0.3rem" }}>{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ borderBottom: "1px solid oklch(0.25 0.06 280)", marginBottom: "1.5rem", display: "flex", gap: "0.25rem", flexWrap: "wrap" }}>
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ ...S.tab(activeTab === tab.id), display: "flex", alignItems: "center", gap: "0.4rem" }}>
              {tab.icon} {tab.label}
              {tab.badge > 0 && (
                <span style={{ background: "oklch(0.65 0.18 25)", color: "white", borderRadius: "9999px", padding: "0.1rem 0.45rem", fontSize: "0.65rem", fontWeight: "700" }}>{tab.badge}</span>
              )}
            </button>
          ))}
        </div>

        {/* Contenido del tab activo */}
        {activeTab === "reservas" && <ReservasTab />}
        {activeTab === "clientes" && <ClientesTab />}
        {activeTab === "bonos" && <BonosTab />}
        {activeTab === "trabajo" && <TrabajoTab />}
      </div>
      <Footer />
    </div>
  );
}
