import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { ArrowLeft, CheckCircle, Phone, Mail, MessageSquare, Mic, PhoneCall } from "lucide-react";

type TipoConsulta = "amor" | "trabajo" | "salud" | "general";
type MetodoContacto = "whatsapp" | "audio" | "email" | "llamada";

const TIPOS_CONSULTA: { value: TipoConsulta; label: string; icon: string; desc: string }[] = [
  { value: "amor", label: "Amor y Relaciones", icon: "❤️", desc: "Pareja, familia, vínculos afectivos" },
  { value: "trabajo", label: "Trabajo y Dinero", icon: "💼", desc: "Carrera, negocios, prosperidad" },
  { value: "salud", label: "Salud y Bienestar", icon: "🌿", desc: "Energía, equilibrio, sanación" },
  { value: "general", label: "Consulta General", icon: "🔮", desc: "Orientación global de tu vida" },
];

const METODOS_CONTACTO: { value: MetodoContacto; label: string; icon: React.ReactNode; desc: string }[] = [
  { value: "whatsapp", label: "WhatsApp", icon: <MessageSquare size={18} />, desc: "Respuesta por mensaje" },
  { value: "audio", label: "Audio", icon: <Mic size={18} />, desc: "Nota de voz personalizada" },
  { value: "email", label: "Email", icon: <Mail size={18} />, desc: "Lectura detallada por correo" },
  { value: "llamada", label: "Llamada", icon: <PhoneCall size={18} />, desc: "Consulta telefónica directa" },
];

export default function ReservasPage() {
  const [nombre, setNombre] = useState("");
  const [email, setEmail] = useState("");
  const [telefono, setTelefono] = useState("");
  const [tipoConsulta, setTipoConsulta] = useState<TipoConsulta | "">("");
  const [metodoContacto, setMetodoContacto] = useState<MetodoContacto | "">("");
  const [mensaje, setMensaje] = useState("");
  const [enviado, setEnviado] = useState(false);
  const [error, setError] = useState("");

  const reservaMutation = trpc.reservas.crear.useMutation({
    onSuccess: () => {
      setEnviado(true);
      setError("");
    },
    onError: (err) => {
      setError("Ha ocurrido un error al enviar tu reserva. Por favor, inténtalo de nuevo o contáctanos directamente.");
      console.error(err);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!nombre.trim()) { setError("Por favor, introduce tu nombre."); return; }
    if (!tipoConsulta) { setError("Por favor, selecciona el tipo de consulta."); return; }
    if (!metodoContacto) { setError("Por favor, selecciona cómo prefieres que te contactemos."); return; }
    if (metodoContacto === "email" && !email.trim()) { setError("Por favor, introduce tu email para la consulta por correo."); return; }
    if (metodoContacto === "whatsapp" && !telefono.trim()) { setError("Por favor, introduce tu teléfono para contactarte por WhatsApp."); return; }
    if (metodoContacto === "llamada" && !telefono.trim()) { setError("Por favor, introduce tu teléfono para la llamada."); return; }

    reservaMutation.mutate({
      nombre: nombre.trim(),
      email: email.trim() || undefined,
      telefono: telefono.trim() || undefined,
      tipoConsulta,
      metodoContacto,
      mensaje: mensaje.trim() || undefined,
    });
  };

  if (enviado) {
    return (
      <div style={{ minHeight: "100vh", background: "oklch(0.10 0.02 280)" }}>
        <Header />
        <div className="container" style={{ padding: "5rem 1rem", textAlign: "center", maxWidth: "600px" }}>
          <div style={{ fontSize: "4rem", marginBottom: "1.5rem" }}>✨</div>
          <CheckCircle size={60} style={{ color: "oklch(0.72 0.15 65)", margin: "0 auto 1.5rem", display: "block" }} />
          <h1
            className="gradient-gold"
            style={{ fontSize: "2rem", fontWeight: "700", fontFamily: "'Cinzel', serif", marginBottom: "1rem" }}
          >
            ¡Reserva Recibida!
          </h1>
          <p style={{ color: "oklch(0.80 0.05 60)", lineHeight: 1.8, fontFamily: "Georgia, serif", marginBottom: "2rem", fontSize: "1rem" }}>
            Gracias, <strong style={{ color: "oklch(0.85 0.12 65)" }}>{nombre}</strong>. Tu solicitud de consulta ha sido recibida.
            Reina se pondrá en contacto contigo en breve a través de{" "}
            <strong style={{ color: "oklch(0.85 0.12 65)" }}>
              {METODOS_CONTACTO.find(m => m.value === metodoContacto)?.label}
            </strong>.
          </p>

          <div
            className="card-mystic"
            style={{ padding: "1.5rem", marginBottom: "2rem", textAlign: "left" }}
          >
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: "linear-gradient(90deg, transparent, oklch(0.72 0.15 65), transparent)", borderRadius: "1rem 1rem 0 0" }} />
            <h3 style={{ color: "oklch(0.72 0.15 65)", fontFamily: "'Cinzel', serif", fontSize: "0.9rem", marginBottom: "1rem", letterSpacing: "0.1em" }}>
              DATOS DE CONTACTO DIRECTO
            </h3>
            <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
              <a href="tel:+34625815306" style={{ display: "flex", alignItems: "center", gap: "0.6rem", color: "oklch(0.80 0.05 60)", textDecoration: "none", fontFamily: "Georgia, serif", fontSize: "0.9rem" }}>
                <Phone size={16} style={{ color: "oklch(0.72 0.15 65)" }} />
                +34 625 815 306
              </a>
              <a href="mailto:tarotmeiga.es@gmail.com" style={{ display: "flex", alignItems: "center", gap: "0.6rem", color: "oklch(0.80 0.05 60)", textDecoration: "none", fontFamily: "Georgia, serif", fontSize: "0.9rem" }}>
                <Mail size={16} style={{ color: "oklch(0.72 0.15 65)" }} />
                tarotmeiga.es@gmail.com
              </a>
            </div>
          </div>

          <Link href="/" className="btn-gold">
            Volver al Inicio
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "oklch(0.10 0.02 280)" }}>
      <Header />

      <div className="container" style={{ padding: "2rem 1rem 5rem", maxWidth: "750px" }}>
        {/* Breadcrumb */}
        <Link
          href="/"
          style={{
            display: "inline-flex", alignItems: "center", gap: "0.5rem",
            color: "oklch(0.65 0.06 60)", textDecoration: "none",
            fontSize: "0.85rem", fontFamily: "'Cinzel', serif", marginBottom: "2rem",
          }}
          onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = "oklch(0.72 0.15 65)")}
          onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = "oklch(0.65 0.06 60)")}
        >
          <ArrowLeft size={16} />
          Volver al Inicio
        </Link>

        {/* Encabezado */}
        <div style={{ textAlign: "center", marginBottom: "2.5rem" }}>
          <img
            src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663356619570/JeVdqpGYxrYKWdLR.jpg"
            alt="Reina"
            style={{
              width: "90px", height: "90px", objectFit: "cover",
              borderRadius: "50%",
              border: "3px solid oklch(0.72 0.15 65)",
              margin: "0 auto 1rem",
              display: "block",
            }}
          />
          <p style={{ color: "oklch(0.72 0.15 65)", fontSize: "0.8rem", letterSpacing: "0.2em", textTransform: "uppercase", fontFamily: "'Cinzel', serif", marginBottom: "0.5rem" }}>
            ✦ Consulta Personal ✦
          </p>
          <h1
            className="gradient-gold"
            style={{ fontSize: "2.2rem", fontWeight: "700", fontFamily: "'Cinzel', serif", marginBottom: "0.75rem" }}
          >
            Reservar con Reina
          </h1>
          <p style={{ color: "oklch(0.70 0.05 60)", fontFamily: "Georgia, serif", lineHeight: 1.7, maxWidth: "500px", margin: "0 auto" }}>
            Rellena el formulario y Reina se pondrá en contacto contigo para confirmar
            tu consulta personalizada. Los precios se consultan directamente.
          </p>
        </div>

        {/* Formulario */}
        <div className="card-mystic" style={{ padding: "2rem" }}>
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: "linear-gradient(90deg, transparent, oklch(0.72 0.15 65), transparent)", borderRadius: "1rem 1rem 0 0" }} />

          <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "1.75rem" }}>

            {/* Nombre */}
            <div>
              <label style={{ display: "block", color: "oklch(0.85 0.12 65)", fontFamily: "'Cinzel', serif", fontSize: "0.85rem", letterSpacing: "0.1em", marginBottom: "0.5rem" }}>
                ✦ Tu Nombre *
              </label>
              <input
                type="text"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="¿Cómo te llamas?"
                className="input-mystic"
                required
              />
            </div>

            {/* Tipo de consulta */}
            <div>
              <label style={{ display: "block", color: "oklch(0.85 0.12 65)", fontFamily: "'Cinzel', serif", fontSize: "0.85rem", letterSpacing: "0.1em", marginBottom: "0.75rem" }}>
                ✦ Tipo de Consulta *
              </label>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: "0.75rem" }}>
                {TIPOS_CONSULTA.map(({ value, label, icon, desc }) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setTipoConsulta(value)}
                    style={{
                      padding: "1rem",
                      borderRadius: "0.75rem",
                      border: tipoConsulta === value
                        ? "2px solid oklch(0.72 0.15 65)"
                        : "1px solid oklch(0.28 0.06 285)",
                      background: tipoConsulta === value
                        ? "linear-gradient(135deg, oklch(0.65 0.18 55 / 0.2), oklch(0.72 0.15 65 / 0.2))"
                        : "oklch(0.14 0.03 280)",
                      cursor: "pointer",
                      textAlign: "center",
                      transition: "all 0.2s ease",
                    }}
                  >
                    <div style={{ fontSize: "1.5rem", marginBottom: "0.4rem" }}>{icon}</div>
                    <div style={{ color: tipoConsulta === value ? "oklch(0.85 0.12 65)" : "oklch(0.75 0.05 60)", fontFamily: "'Cinzel', serif", fontSize: "0.78rem", fontWeight: "600", marginBottom: "0.2rem" }}>
                      {label}
                    </div>
                    <div style={{ color: "oklch(0.55 0.04 60)", fontSize: "0.68rem", fontFamily: "Georgia, serif" }}>
                      {desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Método de contacto */}
            <div>
              <label style={{ display: "block", color: "oklch(0.85 0.12 65)", fontFamily: "'Cinzel', serif", fontSize: "0.85rem", letterSpacing: "0.1em", marginBottom: "0.75rem" }}>
                ✦ ¿Cómo Prefieres que te Contactemos? *
              </label>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))", gap: "0.75rem" }}>
                {METODOS_CONTACTO.map(({ value, label, icon, desc }) => (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setMetodoContacto(value)}
                    style={{
                      padding: "1rem 0.75rem",
                      borderRadius: "0.75rem",
                      border: metodoContacto === value
                        ? "2px solid oklch(0.72 0.15 65)"
                        : "1px solid oklch(0.28 0.06 285)",
                      background: metodoContacto === value
                        ? "linear-gradient(135deg, oklch(0.65 0.18 55 / 0.2), oklch(0.72 0.15 65 / 0.2))"
                        : "oklch(0.14 0.03 280)",
                      cursor: "pointer",
                      textAlign: "center",
                      transition: "all 0.2s ease",
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: "0.4rem",
                    }}
                  >
                    <div style={{ color: metodoContacto === value ? "oklch(0.72 0.15 65)" : "oklch(0.65 0.06 60)" }}>
                      {icon}
                    </div>
                    <div style={{ color: metodoContacto === value ? "oklch(0.85 0.12 65)" : "oklch(0.75 0.05 60)", fontFamily: "'Cinzel', serif", fontSize: "0.78rem", fontWeight: "600" }}>
                      {label}
                    </div>
                    <div style={{ color: "oklch(0.55 0.04 60)", fontSize: "0.68rem", fontFamily: "Georgia, serif" }}>
                      {desc}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Email */}
            <div>
              <label style={{ display: "block", color: "oklch(0.85 0.12 65)", fontFamily: "'Cinzel', serif", fontSize: "0.85rem", letterSpacing: "0.1em", marginBottom: "0.5rem" }}>
                ✦ Email {metodoContacto === "email" ? "*" : "(opcional)"}
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="tu@email.com"
                className="input-mystic"
                required={metodoContacto === "email"}
              />
            </div>

            {/* Teléfono */}
            <div>
              <label style={{ display: "block", color: "oklch(0.85 0.12 65)", fontFamily: "'Cinzel', serif", fontSize: "0.85rem", letterSpacing: "0.1em", marginBottom: "0.5rem" }}>
                ✦ Teléfono {(metodoContacto === "whatsapp" || metodoContacto === "llamada") ? "*" : "(opcional)"}
              </label>
              <input
                type="tel"
                value={telefono}
                onChange={(e) => setTelefono(e.target.value)}
                placeholder="+34 600 000 000"
                className="input-mystic"
                required={metodoContacto === "whatsapp" || metodoContacto === "llamada"}
              />
            </div>

            {/* Mensaje */}
            <div>
              <label style={{ display: "block", color: "oklch(0.85 0.12 65)", fontFamily: "'Cinzel', serif", fontSize: "0.85rem", letterSpacing: "0.1em", marginBottom: "0.5rem" }}>
                ✦ Cuéntame algo sobre tu consulta (opcional)
              </label>
              <textarea
                value={mensaje}
                onChange={(e) => setMensaje(e.target.value)}
                placeholder="Describe brevemente lo que quieres consultar, o cualquier detalle que quieras compartir con Reina..."
                className="input-mystic"
                rows={4}
                style={{ resize: "vertical" }}
              />
            </div>

            {/* Nota de precios */}
            <div
              style={{
                padding: "1rem",
                borderRadius: "0.75rem",
                background: "oklch(0.18 0.04 285)",
                border: "1px solid oklch(0.35 0.08 285)",
                display: "flex",
                gap: "0.75rem",
                alignItems: "flex-start",
              }}
            >
              <span style={{ fontSize: "1.2rem", flexShrink: 0 }}>💬</span>
              <div>
                <p style={{ color: "oklch(0.80 0.05 60)", fontSize: "0.85rem", fontFamily: "Georgia, serif", lineHeight: 1.6, margin: 0 }}>
                  <strong style={{ color: "oklch(0.85 0.12 65)", fontFamily: "'Cinzel', serif" }}>Consulta de precios:</strong>{" "}
                  Los precios se acuerdan directamente con Reina según el tipo y duración de la consulta.
                  Puedes contactar directamente al{" "}
                  <a href="tel:+34625815306" style={{ color: "oklch(0.72 0.15 65)", textDecoration: "none" }}>+34 625 815 306</a>{" "}
                  o a{" "}
                  <a href="mailto:tarotmeiga.es@gmail.com" style={{ color: "oklch(0.72 0.15 65)", textDecoration: "none" }}>tarotmeiga.es@gmail.com</a>.
                </p>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div style={{
                padding: "0.75rem 1rem",
                borderRadius: "0.5rem",
                background: "oklch(0.18 0.06 25)",
                border: "1px solid oklch(0.55 0.22 25)",
                color: "oklch(0.85 0.08 25)",
                fontSize: "0.85rem",
                fontFamily: "Georgia, serif",
              }}>
                ⚠️ {error}
              </div>
            )}

            {/* Botón enviar */}
            <button
              type="submit"
              disabled={reservaMutation.isPending}
              className="btn-gold"
              style={{
                width: "100%",
                padding: "1rem",
                fontSize: "0.9rem",
                opacity: reservaMutation.isPending ? 0.7 : 1,
              }}
            >
              {reservaMutation.isPending ? "✨ Enviando tu solicitud..." : "✦ Enviar Solicitud de Reserva"}
            </button>
          </form>
        </div>

        {/* Contacto directo */}
        <div style={{ marginTop: "2rem", textAlign: "center" }}>
          <p style={{ color: "oklch(0.55 0.04 60)", fontSize: "0.85rem", fontFamily: "Georgia, serif", marginBottom: "1rem" }}>
            ¿Prefieres contactar directamente?
          </p>
          <div style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
            <a
              href="tel:+34625815306"
              style={{
                display: "inline-flex", alignItems: "center", gap: "0.5rem",
                padding: "0.6rem 1.25rem",
                border: "1px solid oklch(0.35 0.08 285)",
                borderRadius: "0.5rem",
                color: "oklch(0.75 0.05 60)",
                textDecoration: "none",
                fontSize: "0.85rem",
                fontFamily: "Georgia, serif",
                transition: "all 0.2s ease",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "oklch(0.72 0.15 65)"; (e.currentTarget as HTMLElement).style.color = "oklch(0.85 0.12 65)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "oklch(0.35 0.08 285)"; (e.currentTarget as HTMLElement).style.color = "oklch(0.75 0.05 60)"; }}
            >
              <Phone size={14} />
              +34 625 815 306
            </a>
            <a
              href="mailto:tarotmeiga.es@gmail.com"
              style={{
                display: "inline-flex", alignItems: "center", gap: "0.5rem",
                padding: "0.6rem 1.25rem",
                border: "1px solid oklch(0.35 0.08 285)",
                borderRadius: "0.5rem",
                color: "oklch(0.75 0.05 60)",
                textDecoration: "none",
                fontSize: "0.85rem",
                fontFamily: "Georgia, serif",
                transition: "all 0.2s ease",
              }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "oklch(0.72 0.15 65)"; (e.currentTarget as HTMLElement).style.color = "oklch(0.85 0.12 65)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "oklch(0.35 0.08 285)"; (e.currentTarget as HTMLElement).style.color = "oklch(0.75 0.05 60)"; }}
            >
              <Mail size={14} />
              tarotmeiga.es@gmail.com
            </a>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
