import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Star, Phone, MessageCircle, Calendar, ChevronRight } from "lucide-react";
export default function Home() {
  const { data: tarotistas, isLoading } = trpc.tarotistas.list.useQuery();

  return (
    <div style={{ minHeight: "100vh", background: "oklch(0.10 0.02 280)" }}>
      <Header />

      {/* HERO */}
      <section
        style={{
          position: "relative",
          padding: "5rem 0 4rem",
          textAlign: "center",
          overflow: "hidden",
        }}
      >
        {/* Fondo decorativo */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage:
              "radial-gradient(ellipse at 50% 0%, oklch(0.25 0.10 290 / 0.5) 0%, transparent 60%)",
            pointerEvents: "none",
          }}
        />
        {/* Estrellas decorativas */}
        <div style={{ position: "absolute", inset: 0, pointerEvents: "none", overflow: "hidden" }}>
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              style={{
                position: "absolute",
                width: "2px",
                height: "2px",
                borderRadius: "50%",
                background: "oklch(0.85 0.12 65)",
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                opacity: Math.random() * 0.7 + 0.3,
              }}
            />
          ))}
        </div>

        <div className="container" style={{ position: "relative" }}>
          <img
            src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663356619570/dsLtSRVAHZMAsXew.png"
            alt="Tarot Meiga"
            className="animate-float"
            style={{ width: "130px", height: "130px", objectFit: "contain", margin: "0 auto 1.5rem" }}
          />
          <h1
            className="gradient-gold"
            style={{
              fontSize: "clamp(2.5rem, 6vw, 4.5rem)",
              fontWeight: "900",
              fontFamily: "'Cinzel', serif",
              letterSpacing: "0.15em",
              marginBottom: "0.5rem",
              lineHeight: 1.1,
            }}
          >
            TAROT MEIGA
          </h1>
          <p
            style={{
              fontSize: "1rem",
              color: "oklch(0.65 0.06 60)",
              letterSpacing: "0.3em",
              textTransform: "uppercase",
              fontFamily: "'Cinzel', serif",
              marginBottom: "1.5rem",
            }}
          >
            ✦ Sabiduría Ancestral ✦
          </p>
          <p
            style={{
              fontSize: "1.1rem",
              color: "oklch(0.80 0.05 60)",
              maxWidth: "600px",
              margin: "0 auto 2.5rem",
              lineHeight: 1.8,
              fontFamily: "Georgia, serif",
            }}
          >
            Descubre los mensajes que las cartas tienen para ti. Consulta con nuestras
            tarotistas de IA o reserva una sesión personal con Reina, nuestra maestra del tarot.
          </p>
          <div style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
            <a href="#tarotistas" className="btn-gold">
              ✦ Consultar Tarotistas IA
            </a>
            <Link href="/reservar" style={{
              display: "inline-block",
              padding: "0.75rem 2rem",
              border: "1px solid oklch(0.72 0.15 65)",
              color: "oklch(0.85 0.12 65)",
              borderRadius: "0.5rem",
              textDecoration: "none",
              fontFamily: "'Cinzel', serif",
              fontSize: "0.875rem",
              letterSpacing: "0.05em",
              textTransform: "uppercase",
              transition: "all 0.3s ease",
            }}>
              Reservar con Reina
            </Link>
          </div>
        </div>
      </section>

      <hr className="divider-gold" style={{ margin: "0" }} />

      {/* SECCIÓN REINA */}
      <section id="reina" style={{ padding: "5rem 0" }}>
        <div className="container">
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
              gap: "3rem",
              alignItems: "center",
              maxWidth: "900px",
              margin: "0 auto",
            }}
          >
            {/* Foto Reina */}
            <div style={{ textAlign: "center" }}>
              <div
                style={{
                  position: "relative",
                  display: "inline-block",
                }}
              >
                <div
                  style={{
                    position: "absolute",
                    inset: "-4px",
                    borderRadius: "1rem",
                    background: "linear-gradient(135deg, oklch(0.72 0.15 65), oklch(0.45 0.18 290), oklch(0.72 0.15 65))",
                    zIndex: 0,
                  }}
                />
                <img
                  src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663356619570/JeVdqpGYxrYKWdLR.jpg"
                  alt="Reina - Tarotista"
                  style={{
                    width: "280px",
                    height: "320px",
                    objectFit: "cover",
                    borderRadius: "0.75rem",
                    position: "relative",
                    zIndex: 1,
                    display: "block",
                  }}
                />
                <div
                  style={{
                    position: "absolute",
                    bottom: "-1px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    background: "linear-gradient(135deg, oklch(0.65 0.18 55), oklch(0.72 0.15 65))",
                    color: "oklch(0.10 0.02 280)",
                    padding: "0.4rem 1.5rem",
                    borderRadius: "0 0 0.75rem 0.75rem",
                    fontFamily: "'Cinzel', serif",
                    fontWeight: "700",
                    fontSize: "0.9rem",
                    letterSpacing: "0.1em",
                    zIndex: 2,
                    whiteSpace: "nowrap",
                  }}
                >
                  ♛ REINA
                </div>
              </div>
            </div>

            {/* Info Reina */}
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.5rem" }}>
                <Star size={16} style={{ color: "oklch(0.72 0.15 65)" }} />
                <span style={{ color: "oklch(0.72 0.15 65)", fontSize: "0.8rem", letterSpacing: "0.2em", textTransform: "uppercase", fontFamily: "'Cinzel', serif" }}>
                  Tarotista Humana · Maestra del Tarot
                </span>
              </div>
              <h2
                className="gradient-gold"
                style={{
                  fontSize: "2.5rem",
                  fontWeight: "700",
                  fontFamily: "'Cinzel', serif",
                  marginBottom: "1rem",
                  lineHeight: 1.1,
                }}
              >
                Reina
              </h2>
              <p style={{ color: "oklch(0.80 0.05 60)", lineHeight: 1.8, marginBottom: "1rem", fontFamily: "Georgia, serif" }}>
                Con más de 20 años de experiencia en el arte del tarot y las artes adivinatorias,
                Reina es la guía espiritual de Tarot Meiga. Su don natural y su profunda conexión
                con las cartas le permiten revelar los mensajes más precisos y transformadores.
              </p>
              <p style={{ color: "oklch(0.75 0.05 60)", lineHeight: 1.8, marginBottom: "2rem", fontFamily: "Georgia, serif" }}>
                Especializada en amor, relaciones, trabajo y orientación espiritual, Reina ofrece
                consultas personalizadas por WhatsApp, audio, email o llamada telefónica.
                Cada sesión es única, confidencial y llena de sabiduría ancestral.
              </p>

              {/* Métodos de contacto */}
              <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap", marginBottom: "1.5rem" }}>
                {[
                  { icon: "💬", label: "WhatsApp" },
                  { icon: "🎵", label: "Audio" },
                  { icon: "📧", label: "Email" },
                  { icon: "📞", label: "Llamada" },
                ].map(({ icon, label }) => (
                  <span key={label} className="badge-especialidad">
                    {icon} {label}
                  </span>
                ))}
              </div>

              <div style={{ display: "flex", gap: "1rem", flexWrap: "wrap" }}>
                <Link href="/reservar" className="btn-gold">
                  <Calendar size={16} style={{ display: "inline", marginRight: "0.5rem" }} />
                  Reservar Consulta
                </Link>
                <a
                  href="tel:+34625815306"
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: "0.5rem",
                    padding: "0.75rem 1.5rem",
                    border: "1px solid oklch(0.72 0.15 65 / 0.5)",
                    color: "oklch(0.85 0.12 65)",
                    borderRadius: "0.5rem",
                    textDecoration: "none",
                    fontFamily: "'Cinzel', serif",
                    fontSize: "0.8rem",
                    letterSpacing: "0.05em",
                    transition: "all 0.3s ease",
                  }}
                >
                  <Phone size={14} />
                  Llamar Ahora
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <hr className="divider-gold" style={{ margin: "0" }} />

      {/* GALERÍA TAROTISTAS IA */}
      <section id="tarotistas" style={{ padding: "5rem 0" }}>
        <div className="container">
          <div style={{ textAlign: "center", marginBottom: "3rem" }}>
            <p style={{ color: "oklch(0.72 0.15 65)", fontSize: "0.8rem", letterSpacing: "0.3em", textTransform: "uppercase", fontFamily: "'Cinzel', serif", marginBottom: "0.5rem" }}>
              ✦ Inteligencia Ancestral ✦
            </p>
            <h2
              className="gradient-gold"
              style={{
                fontSize: "clamp(1.8rem, 4vw, 2.8rem)",
                fontWeight: "700",
                fontFamily: "'Cinzel', serif",
                marginBottom: "1rem",
              }}
            >
              Nuestras Tarotistas de IA
            </h2>
            <p style={{ color: "oklch(0.70 0.05 60)", maxWidth: "600px", margin: "0 auto", fontFamily: "Georgia, serif", lineHeight: 1.7 }}>
              Cada tarotista tiene su propia personalidad, especialidad y estilo único.
              Elige la que más resuene contigo y realiza tu <strong style={{ color: "oklch(0.85 0.12 65)" }}>pregunta gratuita</strong>.
            </p>
          </div>

          {isLoading ? (
            <div style={{ textAlign: "center", padding: "4rem", color: "oklch(0.65 0.06 60)" }}>
              <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>🔮</div>
              <p style={{ fontFamily: "'Cinzel', serif" }}>Las cartas se están preparando...</p>
            </div>
          ) : (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
                gap: "1.25rem",
              }}
            >
              {tarotistas?.map((t) => (
                <Link key={t.id} href={`/tarotista/${t.id}`} style={{ textDecoration: "none" }}>
                  <div
                    className="card-mystic"
                    style={{
                      padding: "1.5rem 1rem",
                      textAlign: "center",
                      cursor: "pointer",
                      height: "100%",
                    }}
                  >
                    {/* Línea de color superior */}
                    <div
                      style={{
                        position: "absolute",
                        top: 0,
                        left: 0,
                        right: 0,
                        height: "3px",
                        background: `linear-gradient(90deg, transparent, ${t.color}, transparent)`,
                        borderRadius: "1rem 1rem 0 0",
                      }}
                    />

                    <div style={{ width: "100%", height: "160px", overflow: "hidden", borderRadius: "0.5rem", marginBottom: "0.75rem", position: "relative" }}>
                      <img
                        src={t.imagen || ""}
                        alt={t.nombre}
                        style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center top", display: "block" }}
                        onError={(e) => {
                          const el = e.currentTarget;
                          el.style.display = "none";
                          const parent = el.parentElement;
                          if (parent) {
                            parent.style.display = "flex";
                            parent.style.alignItems = "center";
                            parent.style.justifyContent = "center";
                            parent.style.fontSize = "3rem";
                            parent.style.background = "oklch(0.15 0.04 280)";
                            parent.textContent = t.avatar;
                          }
                        }}
                      />
                    </div>

                    <h3
                      style={{
                        fontSize: "0.95rem",
                        fontWeight: "700",
                        fontFamily: "'Cinzel', serif",
                        color: "oklch(0.92 0.04 60)",
                        marginBottom: "0.4rem",
                      }}
                    >
                      {t.nombre}
                    </h3>

                    <p
                      style={{
                        fontSize: "0.72rem",
                        color: "oklch(0.72 0.15 65)",
                        fontFamily: "'Cinzel', serif",
                        letterSpacing: "0.05em",
                        marginBottom: "0.75rem",
                      }}
                    >
                      {t.especialidad}
                    </p>

                    <p
                      style={{
                        fontSize: "0.75rem",
                        color: "oklch(0.65 0.05 60)",
                        lineHeight: 1.5,
                        fontFamily: "Georgia, serif",
                        marginBottom: "1rem",
                      }}
                    >
                      {t.descripcionCorta}
                    </p>

                    <div
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "0.4rem",
                        background: "linear-gradient(135deg, oklch(0.65 0.18 55 / 0.2), oklch(0.72 0.15 65 / 0.2))",
                        border: "1px solid oklch(0.72 0.15 65 / 0.4)",
                        color: "oklch(0.85 0.12 65)",
                        padding: "0.35rem 0.9rem",
                        borderRadius: "9999px",
                        fontSize: "0.7rem",
                        fontFamily: "'Cinzel', serif",
                        letterSpacing: "0.05em",
                      }}
                    >
                      <MessageCircle size={11} />
                      1 Pregunta Gratis
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>


      {/* SECCIÓN TESTIMONIOS */}
      <section style={{ padding: "4rem 0", background: "oklch(0.12 0.03 280)" }}>
        <div className="container">
          <div style={{ textAlign: "center", marginBottom: "2.5rem" }}>
            <p style={{ color: "oklch(0.72 0.15 65)", fontSize: "0.8rem", letterSpacing: "0.3em", textTransform: "uppercase", fontFamily: "'Cinzel', serif", marginBottom: "0.5rem" }}>✦ Testimonios ✦</p>
            <h2 className="gradient-gold" style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(1.6rem, 4vw, 2.5rem)", fontWeight: "900", letterSpacing: "0.1em", marginBottom: "0.75rem" }}>
              Lo Que Dicen Nuestros Clientes
            </h2>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "1.5rem", marginBottom: "2rem" }}>
            {[
              { nombre: "María G.", texto: "Una experiencia transformadora. Luna Oscura me ayudó a entender mi situación sentimental con una claridad increíble.", puntuacion: 5, tarotista: "Luna Oscura" },
              { nombre: "Carlos M.", texto: "Reina es una persona excepcional. Su lectura fue precisa y me dio la guía que necesitaba para tomar una decisión importante.", puntuacion: 5, tarotista: "Reina" },
              { nombre: "Ana P.", texto: "El chat con Sol Dorado me abrió los ojos sobre mi carrera. La pregunta gratuita valió muchísimo.", puntuacion: 5, tarotista: "Sol Dorado" },
            ].map((t, i) => (
              <div key={i} style={{ background: "oklch(0.14 0.03 280)", border: "1px solid oklch(0.25 0.06 280)", borderRadius: "0.75rem", padding: "1.5rem", position: "relative", overflow: "hidden" }}>
                <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: "linear-gradient(90deg, transparent, oklch(0.72 0.15 65), transparent)" }} />
                <div style={{ display: "flex", gap: "0.3rem", marginBottom: "0.75rem" }}>
                  {[...Array(t.puntuacion)].map((_, s) => <Star key={s} size={14} fill="oklch(0.72 0.15 65)" stroke="oklch(0.72 0.15 65)" />)}
                </div>
                <p style={{ color: "oklch(0.85 0.04 60)", fontFamily: "Georgia, serif", fontSize: "0.88rem", lineHeight: 1.7, fontStyle: "italic", marginBottom: "1rem" }}>
                  {t.texto}
                </p>
                <div style={{ borderTop: "1px solid oklch(0.22 0.05 280)", paddingTop: "0.75rem" }}>
                  <p style={{ color: "oklch(0.72 0.15 65)", fontFamily: "'Cinzel', serif", fontSize: "0.82rem", fontWeight: "700" }}>{t.nombre}</p>
                  <p style={{ color: "oklch(0.55 0.05 60)", fontFamily: "Georgia, serif", fontSize: "0.72rem" }}>Consultó con: {t.tarotista}</p>
                </div>
              </div>
            ))}
          </div>
          <div style={{ textAlign: "center" }}>
            <Link href="/resenas" style={{ display: "inline-flex", alignItems: "center", gap: "0.5rem", color: "oklch(0.72 0.15 65)", fontFamily: "'Cinzel', serif", fontSize: "0.85rem", textDecoration: "none", border: "1px solid oklch(0.72 0.15 65 / 0.4)", padding: "0.65rem 1.5rem", borderRadius: "0.5rem" }}>
              Ver Todos los Testimonios <ChevronRight size={15} />
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
