import { useState } from "react";
import { trpc } from "@/lib/trpc";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Star, Send, MessageCircle } from "lucide-react";
import { toast } from "sonner";

const S = {
  bg: "oklch(0.10 0.02 280)",
  card: { background: "oklch(0.14 0.03 280)", border: "1px solid oklch(0.25 0.06 280)", borderRadius: "0.75rem", padding: "1.5rem", position: "relative" as const, overflow: "hidden" as const },
  gold: "oklch(0.72 0.15 65)",
  goldLight: "oklch(0.85 0.12 65)",
  muted: "oklch(0.65 0.05 60)",
  text: "oklch(0.92 0.04 60)",
  input: { background: "oklch(0.18 0.04 280)", border: "1px solid oklch(0.30 0.06 280)", color: "oklch(0.92 0.04 60)", padding: "0.75rem 1rem", borderRadius: "0.5rem", fontFamily: "Georgia, serif", fontSize: "0.9rem", width: "100%", boxSizing: "border-box" as const },
  btn: { background: "linear-gradient(135deg, oklch(0.65 0.18 55), oklch(0.72 0.15 65))", color: "oklch(0.10 0.02 280)", border: "none", padding: "0.85rem 2rem", borderRadius: "0.5rem", cursor: "pointer", fontFamily: "'Cinzel', serif", fontSize: "0.85rem", fontWeight: "700", letterSpacing: "0.05em" },
};

function StarRating({ value, onChange }: { value: number; onChange?: (v: number) => void }) {
  return (
    <div style={{ display: "flex", gap: "0.35rem" }}>
      {[1, 2, 3, 4, 5].map(n => (
        <button
          key={n}
          type="button"
          onClick={() => onChange?.(n)}
          style={{ background: "none", border: "none", cursor: onChange ? "pointer" : "default", padding: "0" }}
        >
          <Star
            size={22}
            fill={n <= value ? "oklch(0.72 0.15 65)" : "transparent"}
            stroke={n <= value ? "oklch(0.72 0.15 65)" : "oklch(0.45 0.05 60)"}
          />
        </button>
      ))}
    </div>
  );
}

export default function ResenasPage() {
  const { data: resenas, isLoading, refetch } = trpc.resenas.listar.useQuery({ soloVisibles: true });
  const crearMutation = trpc.resenas.crear.useMutation();

  const [form, setForm] = useState({
    nombre: "",
    email: "",
    texto: "",
    puntuacion: 5,
    tarotistaNombre: "",
  });
  const [enviado, setEnviado] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await crearMutation.mutateAsync({
        nombre: form.nombre,
        email: form.email || undefined,
        texto: form.texto,
        puntuacion: form.puntuacion,
        tarotistaNombre: form.tarotistaNombre || undefined,
      });
      setEnviado(true);
      toast.success("¡Gracias por tu reseña! Será publicada tras revisión.");
      setForm({ nombre: "", email: "", texto: "", puntuacion: 5, tarotistaNombre: "" });
    } catch {
      toast.error("Error al enviar la reseña. Por favor, inténtalo de nuevo.");
    }
  };

  const formatFecha = (date: Date | string) => {
    return new Date(date).toLocaleDateString("es-ES", { year: "numeric", month: "long", day: "numeric" });
  };

  return (
    <div style={{ minHeight: "100vh", background: S.bg }}>
      <Header />

      {/* Hero */}
      <section style={{ padding: "4rem 0 2rem", textAlign: "center", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(ellipse at 50% 0%, oklch(0.25 0.10 290 / 0.4) 0%, transparent 60%)", pointerEvents: "none" }} />
        <div className="container" style={{ position: "relative" }}>
          <p style={{ color: S.gold, fontSize: "0.8rem", letterSpacing: "0.3em", textTransform: "uppercase", fontFamily: "'Cinzel', serif", marginBottom: "0.75rem" }}>✦ Testimonios ✦</p>
          <h1 className="gradient-gold" style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: "900", marginBottom: "1rem", letterSpacing: "0.1em" }}>
            Experiencias de Nuestros Clientes
          </h1>
          <p style={{ color: S.muted, maxWidth: "600px", margin: "0 auto", fontFamily: "Georgia, serif", lineHeight: 1.8, fontSize: "1rem" }}>
            Las palabras de quienes han encontrado guía y claridad a través de Tarot Meiga.
          </p>
        </div>
      </section>

      <hr className="divider-gold" style={{ margin: "0" }} />

      {/* Testimonios visibles */}
      <section style={{ padding: "4rem 0" }}>
        <div className="container">
          {isLoading ? (
            <div style={{ textAlign: "center", padding: "4rem", color: S.muted }}>
              <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>🔮</div>
              <p style={{ fontFamily: "'Cinzel', serif" }}>Cargando testimonios...</p>
            </div>
          ) : !resenas || resenas.length === 0 ? (
            <div style={{ textAlign: "center", padding: "4rem", color: S.muted }}>
              <MessageCircle size={48} style={{ margin: "0 auto 1rem", opacity: 0.4 }} />
              <p style={{ fontFamily: "'Cinzel', serif", fontSize: "1.1rem", marginBottom: "0.5rem" }}>Aún no hay testimonios publicados</p>
              <p style={{ fontFamily: "Georgia, serif", fontSize: "0.9rem" }}>¡Sé el primero en compartir tu experiencia!</p>
            </div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "1.5rem" }}>
              {resenas.map(r => (
                <div key={r.id} style={S.card}>
                  <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: "linear-gradient(90deg, transparent, oklch(0.72 0.15 65), transparent)" }} />

                  {/* Estrellas */}
                  <div style={{ marginBottom: "0.75rem" }}>
                    <StarRating value={r.puntuacion} />
                  </div>

                  {/* Texto */}
                  <p style={{ color: S.text, fontFamily: "Georgia, serif", fontSize: "0.92rem", lineHeight: 1.7, marginBottom: "1.25rem", fontStyle: "italic" }}>
                    "{r.texto}"
                  </p>

                  {/* Autor */}
                  <div style={{ borderTop: "1px solid oklch(0.25 0.06 280)", paddingTop: "0.75rem", display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
                    <div>
                      <p style={{ color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.85rem", fontWeight: "700" }}>{r.nombre}</p>
                      {r.tarotistaNombre && (
                        <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.75rem" }}>Consultó con: {r.tarotistaNombre}</p>
                      )}
                    </div>
                    <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.72rem" }}>{formatFecha(r.createdAt)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Formulario de nueva reseña */}
      <section style={{ padding: "0 0 5rem" }}>
        <div className="container" style={{ maxWidth: "600px" }}>
          <div style={S.card}>
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: "linear-gradient(90deg, transparent, oklch(0.72 0.15 65), transparent)" }} />

            <h2 style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontSize: "1.3rem", fontWeight: "700", marginBottom: "0.5rem", textAlign: "center" }}>
              ✦ Comparte Tu Experiencia
            </h2>
            <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.85rem", textAlign: "center", marginBottom: "1.5rem", lineHeight: 1.6 }}>
              Tu reseña será revisada por Reina antes de ser publicada.
            </p>

            {enviado ? (
              <div style={{ textAlign: "center", padding: "2rem" }}>
                <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>✨</div>
                <h3 style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, marginBottom: "0.5rem" }}>¡Gracias por tu testimonio!</h3>
                <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.9rem" }}>Tu reseña será publicada tras ser revisada por Reina.</p>
                <button onClick={() => setEnviado(false)} style={{ ...S.btn, marginTop: "1.5rem", padding: "0.65rem 1.5rem" }}>
                  Escribir otra reseña
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
                <div>
                  <label style={{ display: "block", color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.78rem", marginBottom: "0.4rem", letterSpacing: "0.05em" }}>NOMBRE *</label>
                  <input required value={form.nombre} onChange={e => setForm(f => ({ ...f, nombre: e.target.value }))} placeholder="Tu nombre" style={S.input} />
                </div>
                <div>
                  <label style={{ display: "block", color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.78rem", marginBottom: "0.4rem", letterSpacing: "0.05em" }}>EMAIL (OPCIONAL)</label>
                  <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="tu@email.com" style={S.input} />
                </div>
                <div>
                  <label style={{ display: "block", color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.78rem", marginBottom: "0.4rem", letterSpacing: "0.05em" }}>TAROTISTA CONSULTADA (OPCIONAL)</label>
                  <input value={form.tarotistaNombre} onChange={e => setForm(f => ({ ...f, tarotistaNombre: e.target.value }))} placeholder="Ej: Reina, Luna Oscura..." style={S.input} />
                </div>
                <div>
                  <label style={{ display: "block", color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.78rem", marginBottom: "0.4rem", letterSpacing: "0.05em" }}>PUNTUACIÓN *</label>
                  <StarRating value={form.puntuacion} onChange={v => setForm(f => ({ ...f, puntuacion: v }))} />
                </div>
                <div>
                  <label style={{ display: "block", color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.78rem", marginBottom: "0.4rem", letterSpacing: "0.05em" }}>TU EXPERIENCIA *</label>
                  <textarea
                    required
                    value={form.texto}
                    onChange={e => setForm(f => ({ ...f, texto: e.target.value }))}
                    placeholder="Cuéntanos cómo fue tu experiencia con Tarot Meiga..."
                    rows={5}
                    minLength={10}
                    maxLength={1000}
                    style={{ ...S.input, resize: "vertical" }}
                  />
                  <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.72rem", marginTop: "0.25rem" }}>{form.texto.length}/1000 caracteres</p>
                </div>

                <button type="submit" style={{ ...S.btn, display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5rem" }} disabled={crearMutation.isPending}>
                  <Send size={16} />
                  {crearMutation.isPending ? "Enviando..." : "Enviar Reseña"}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
