import Header from "@/components/Header";
import Footer from "@/components/Footer";

const S = {
  bg: "oklch(0.10 0.02 280)",
  card: { background: "oklch(0.14 0.03 280)", border: "1px solid oklch(0.25 0.06 280)", borderRadius: "0.75rem", padding: "2.5rem", position: "relative" as const, overflow: "hidden" as const },
  gold: "oklch(0.72 0.15 65)",
  goldLight: "oklch(0.85 0.12 65)",
  muted: "oklch(0.65 0.05 60)",
  text: "oklch(0.85 0.04 60)",
  h2: { fontFamily: "'Cinzel', serif", color: "oklch(0.85 0.12 65)", fontSize: "1.1rem", fontWeight: "700", marginBottom: "0.75rem", marginTop: "2rem" },
  p: { color: "oklch(0.75 0.04 60)", fontFamily: "Georgia, serif", lineHeight: 1.8, fontSize: "0.9rem", marginBottom: "0.75rem" },
};

export default function LegalPage() {
  return (
    <div style={{ minHeight: "100vh", background: S.bg }}>
      <Header />

      <section style={{ padding: "3rem 0 5rem" }}>
        <div className="container" style={{ maxWidth: "800px" }}>
          <div style={{ textAlign: "center", marginBottom: "3rem" }}>
            <p style={{ color: S.gold, fontSize: "0.8rem", letterSpacing: "0.3em", textTransform: "uppercase", fontFamily: "'Cinzel', serif", marginBottom: "0.75rem" }}>✦ Tarot Meiga ✦</p>
            <h1 className="gradient-gold" style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(1.8rem, 4vw, 2.8rem)", fontWeight: "900", marginBottom: "0.75rem" }}>
              Aviso Legal & Privacidad
            </h1>
            <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.9rem" }}>Última actualización: Febrero 2025</p>
          </div>

          <div style={S.card}>
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: "linear-gradient(90deg, transparent, oklch(0.72 0.15 65), transparent)" }} />

            <h2 style={{ ...S.h2, marginTop: 0 }}>1. Aviso Legal e Identificación</h2>
            <p style={S.p}>En cumplimiento de la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y de Comercio Electrónico (LSSICE), se informa que el presente sitio web <strong style={{ color: S.goldLight }}>tarotmeiga.es</strong> es titularidad de Tarot Meiga - Sabiduría Ancestral.</p>
            <p style={S.p}><strong style={{ color: S.goldLight }}>Datos de contacto:</strong><br />Email: tarotmeiga.es@gmail.com<br />Teléfono: +34 625 815 306</p>

            <h2 style={S.h2}>2. Objeto y Naturaleza del Servicio</h2>
            <p style={S.p}>Tarot Meiga ofrece servicios de entretenimiento, orientación y consultoría espiritual a través de lecturas de tarot, tanto con inteligencia artificial como con tarotistas humanas profesionales. Los servicios prestados tienen carácter <strong style={{ color: S.goldLight }}>exclusivamente orientativo y de entretenimiento</strong>.</p>
            <p style={S.p}>Las lecturas de tarot y consultas espirituales no constituyen asesoramiento médico, psicológico, legal, financiero ni de ningún otro tipo profesional. Tarot Meiga no se hace responsable de las decisiones tomadas por los usuarios basándose en las lecturas recibidas.</p>

            <h2 style={S.h2}>3. Política de Privacidad y Protección de Datos</h2>
            <p style={S.p}>En cumplimiento del Reglamento (UE) 2016/679 (RGPD) y la Ley Orgánica 3/2018 de Protección de Datos Personales (LOPDGDD), Tarot Meiga informa sobre el tratamiento de datos personales.</p>
            <p style={S.p}><strong style={{ color: S.goldLight }}>Responsable del tratamiento:</strong> Tarot Meiga - Sabiduría Ancestral<br /><strong style={{ color: S.goldLight }}>Finalidad:</strong> Gestión de reservas, comunicaciones con clientes, prestación de servicios solicitados y atención al cliente.<br /><strong style={{ color: S.goldLight }}>Base legal:</strong> Ejecución de contrato y consentimiento del interesado.<br /><strong style={{ color: S.goldLight }}>Destinatarios:</strong> Los datos no serán cedidos a terceros salvo obligación legal.<br /><strong style={{ color: S.goldLight }}>Conservación:</strong> Los datos se conservarán durante el tiempo necesario para la prestación del servicio y el cumplimiento de obligaciones legales.</p>
            <p style={S.p}>El usuario puede ejercer sus derechos de acceso, rectificación, supresión, limitación, portabilidad y oposición enviando un email a: <strong style={{ color: S.goldLight }}>tarotmeiga.es@gmail.com</strong></p>

            <h2 style={S.h2}>4. Política de Cookies</h2>
            <p style={S.p}>Este sitio web utiliza cookies propias y de terceros para mejorar la experiencia de navegación y analizar el uso del sitio. Las cookies utilizadas son:</p>
            <p style={S.p}><strong style={{ color: S.goldLight }}>Cookies técnicas (necesarias):</strong> Imprescindibles para el funcionamiento del sitio web. No requieren consentimiento.<br /><strong style={{ color: S.goldLight }}>Cookies de preferencias:</strong> Recuerdan tus preferencias de navegación (como el aviso de cookies aceptado).<br /><strong style={{ color: S.goldLight }}>Cookies de análisis:</strong> Nos ayudan a entender cómo los usuarios interactúan con el sitio para mejorarlo.</p>
            <p style={S.p}>Puedes configurar tu navegador para rechazar las cookies o ser informado cuando se instalen. Sin embargo, algunas funcionalidades del sitio pueden verse afectadas.</p>

            <h2 style={S.h2}>5. Propiedad Intelectual</h2>
            <p style={S.p}>Todos los contenidos del sitio web (textos, imágenes, logotipos, diseño gráfico, código fuente) son propiedad de Tarot Meiga o de sus respectivos autores, y están protegidos por las leyes de propiedad intelectual e industrial. Queda prohibida su reproducción, distribución o modificación sin autorización expresa.</p>

            <h2 style={S.h2}>6. Condiciones de Uso</h2>
            <p style={S.p}>El acceso y uso de este sitio web implica la aceptación de las presentes condiciones. El usuario se compromete a hacer un uso lícito y adecuado del sitio, respetando la legislación vigente y los derechos de terceros.</p>
            <p style={S.p}>Tarot Meiga se reserva el derecho de modificar, suspender o cancelar el acceso al sitio web en cualquier momento y sin previo aviso.</p>

            <h2 style={S.h2}>7. Legislación Aplicable</h2>
            <p style={S.p}>Las presentes condiciones se rigen por la legislación española. Para cualquier controversia que pudiera surgir, las partes se someten a los Juzgados y Tribunales del domicilio del usuario, salvo que la ley disponga otra cosa.</p>

            <div style={{ marginTop: "2.5rem", padding: "1.25rem", background: "oklch(0.65 0.18 55 / 0.08)", border: "1px solid oklch(0.72 0.15 65 / 0.3)", borderRadius: "0.5rem" }}>
              <p style={{ ...S.p, marginBottom: 0, textAlign: "center" }}>
                Para cualquier consulta sobre privacidad o protección de datos, contáctanos en:<br />
                <strong style={{ color: S.goldLight }}>tarotmeiga.es@gmail.com</strong> · <strong style={{ color: S.goldLight }}>+34 625 815 306</strong>
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
