import { useState } from "react";
import { trpc } from "@/lib/trpc";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { CheckCircle, Star } from "lucide-react";

const S = {
  bg: "oklch(0.10 0.02 280)",
  card: { background: "oklch(0.14 0.03 280)", border: "1px solid oklch(0.25 0.06 280)", borderRadius: "0.75rem", padding: "2rem", position: "relative" as const, overflow: "hidden" as const },
  gold: "oklch(0.72 0.15 65)",
  goldLight: "oklch(0.85 0.12 65)",
  muted: "oklch(0.65 0.05 60)",
  text: "oklch(0.92 0.04 60)",
  input: { background: "oklch(0.18 0.04 280)", border: "1px solid oklch(0.30 0.06 280)", color: "oklch(0.92 0.04 60)", padding: "0.75rem 1rem", borderRadius: "0.5rem", fontFamily: "Georgia, serif", fontSize: "0.9rem", width: "100%", boxSizing: "border-box" as const },
  btn: { background: "linear-gradient(135deg, oklch(0.65 0.18 55), oklch(0.72 0.15 65))", color: "oklch(0.10 0.02 280)", border: "none", padding: "0.9rem 2.5rem", borderRadius: "0.5rem", cursor: "pointer", fontFamily: "'Cinzel', serif", fontSize: "0.9rem", fontWeight: "700", letterSpacing: "0.05em" },
  label: { display: "block" as const, color: "oklch(0.72 0.15 65)", fontFamily: "'Cinzel', serif", fontSize: "0.78rem", marginBottom: "0.4rem", letterSpacing: "0.05em" },
};

const beneficios = [
  { icon: "🌙", title: "Flexibilidad Total", desc: "Trabaja desde donde quieras, a tus horas. Tú decides tu disponibilidad." },
  { icon: "💰", title: "Ingresos Atractivos", desc: "Comisiones competitivas por cada consulta realizada a través de la plataforma." },
  { icon: "✨", title: "Comunidad Mística", desc: "Únete a una comunidad de profesionales del tarot y las artes adivinatorias." },
  { icon: "🔮", title: "Plataforma Establecida", desc: "Accede a una base de clientes ya establecida y en crecimiento constante." },
  { icon: "📱", title: "Soporte Completo", desc: "Te proporcionamos todas las herramientas y soporte necesarios para empezar." },
  { icon: "🌟", title: "Visibilidad Online", desc: "Tu perfil profesional visible para miles de personas que buscan orientación espiritual." },
];

export default function TrabajaPage() {
  const mutation = trpc.trabajo.solicitar.useMutation();
  const [success, setSuccess] = useState(false);
  const [form, setForm] = useState({
    nombre: "",
    email: "",
    telefono: "",
    especialidad: "",
    experiencia: "",
    presentacion: "",
    redesSociales: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await mutation.mutateAsync({
      nombre: form.nombre,
      email: form.email,
      telefono: form.telefono || undefined,
      especialidad: form.especialidad,
      experiencia: form.experiencia,
      presentacion: form.presentacion,
      redesSociales: form.redesSociales || undefined,
    });
    setSuccess(true);
  };

  return (
    <div style={{ minHeight: "100vh", background: S.bg }}>
      <Header />

      {/* Hero */}
      <section style={{ padding: "4rem 0 3rem", textAlign: "center", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(ellipse at 50% 0%, oklch(0.25 0.10 290 / 0.4) 0%, transparent 60%)", pointerEvents: "none" }} />
        <div className="container" style={{ position: "relative" }}>
          <p style={{ color: S.gold, fontSize: "0.8rem", letterSpacing: "0.3em", textTransform: "uppercase", fontFamily: "'Cinzel', serif", marginBottom: "0.75rem" }}>✦ Únete a Nosotros ✦</p>
          <h1 className="gradient-gold" style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(2rem, 5vw, 3.5rem)", fontWeight: "900", marginBottom: "1rem", letterSpacing: "0.1em" }}>
            Trabaja con Nosotros
          </h1>
          <p style={{ color: S.muted, maxWidth: "650px", margin: "0 auto", fontFamily: "Georgia, serif", lineHeight: 1.8, fontSize: "1rem" }}>
            ¿Eres tarotista, vidente, astrólogo/a o practicante de artes adivinatorias? Únete a la familia de Tarot Meiga y comparte tu don con el mundo.
          </p>
        </div>
      </section>

      <hr className="divider-gold" style={{ margin: "0" }} />

      {/* Beneficios */}
      <section style={{ padding: "4rem 0" }}>
        <div className="container">
          <h2 className="gradient-gold" style={{ fontFamily: "'Cinzel', serif", fontSize: "clamp(1.5rem, 3vw, 2rem)", fontWeight: "700", textAlign: "center", marginBottom: "2.5rem" }}>
            ¿Por Qué Unirte a Tarot Meiga?
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: "1.25rem", marginBottom: "4rem" }}>
            {beneficios.map((b, i) => (
              <div key={i} style={{ ...S.card, padding: "1.5rem" }}>
                <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: "linear-gradient(90deg, transparent, oklch(0.72 0.15 65), transparent)" }} />
                <div style={{ fontSize: "2rem", marginBottom: "0.75rem" }}>{b.icon}</div>
                <h3 style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontSize: "0.95rem", fontWeight: "700", marginBottom: "0.5rem" }}>{b.title}</h3>
                <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.85rem", lineHeight: 1.6 }}>{b.desc}</p>
              </div>
            ))}
          </div>

          {/* Formulario */}
          {success ? (
            <div style={{ ...S.card, maxWidth: "600px", margin: "0 auto", textAlign: "center", padding: "3rem" }}>
              <CheckCircle size={56} style={{ color: "oklch(0.65 0.18 145)", margin: "0 auto 1.25rem" }} />
              <h3 style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontSize: "1.4rem", marginBottom: "0.75rem" }}>¡Solicitud Recibida!</h3>
              <p style={{ color: S.muted, fontFamily: "Georgia, serif", lineHeight: 1.8 }}>
                Hemos recibido tu solicitud para unirte a Tarot Meiga. Reina revisará tu perfil personalmente y se pondrá en contacto contigo en los próximos días.
              </p>
              <p style={{ color: S.gold, fontFamily: "'Cinzel', serif", fontSize: "0.85rem", marginTop: "1.25rem" }}>
                ✦ Gracias por tu interés en nuestra comunidad ✦
              </p>
            </div>
          ) : (
            <div style={{ ...S.card, maxWidth: "700px", margin: "0 auto" }}>
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: "linear-gradient(90deg, transparent, oklch(0.72 0.15 65), transparent)" }} />
              <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "1.75rem" }}>
                <Star size={20} style={{ color: S.gold }} />
                <h2 style={{ fontFamily: "'Cinzel', serif", color: S.goldLight, fontSize: "1.2rem", fontWeight: "700" }}>Formulario de Solicitud</h2>
              </div>

              <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "1.25rem" }}>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "1rem" }}>
                  <div>
                    <label style={S.label}>NOMBRE COMPLETO *</label>
                    <input required value={form.nombre} onChange={e => setForm(f => ({ ...f, nombre: e.target.value }))} placeholder="Tu nombre artístico o real" style={S.input} />
                  </div>
                  <div>
                    <label style={S.label}>EMAIL *</label>
                    <input required type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="tu@email.com" style={S.input} />
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "1rem" }}>
                  <div>
                    <label style={S.label}>TELÉFONO / WHATSAPP</label>
                    <input value={form.telefono} onChange={e => setForm(f => ({ ...f, telefono: e.target.value }))} placeholder="+34 600 000 000" style={S.input} />
                  </div>
                  <div>
                    <label style={S.label}>ESPECIALIDAD *</label>
                    <input required value={form.especialidad} onChange={e => setForm(f => ({ ...f, especialidad: e.target.value }))} placeholder="Tarot, Astrología, Runas..." style={S.input} />
                  </div>
                </div>

                <div>
                  <label style={S.label}>EXPERIENCIA Y FORMACIÓN *</label>
                  <textarea
                    required
                    value={form.experiencia}
                    onChange={e => setForm(f => ({ ...f, experiencia: e.target.value }))}
                    placeholder="Cuéntanos sobre tu experiencia, años de práctica, formación recibida..."
                    rows={4}
                    style={{ ...S.input, resize: "vertical" }}
                  />
                </div>

                <div>
                  <label style={S.label}>PRESENTACIÓN PERSONAL *</label>
                  <textarea
                    required
                    value={form.presentacion}
                    onChange={e => setForm(f => ({ ...f, presentacion: e.target.value }))}
                    placeholder="¿Quién eres? ¿Cuál es tu don especial? ¿Por qué quieres unirte a Tarot Meiga?"
                    rows={5}
                    style={{ ...S.input, resize: "vertical" }}
                  />
                </div>

                <div>
                  <label style={S.label}>REDES SOCIALES / WEB PERSONAL</label>
                  <input value={form.redesSociales} onChange={e => setForm(f => ({ ...f, redesSociales: e.target.value }))} placeholder="Instagram, TikTok, web..." style={S.input} />
                </div>

                <p style={{ color: S.muted, fontFamily: "Georgia, serif", fontSize: "0.8rem", lineHeight: 1.6 }}>
                  Al enviar este formulario, aceptas que Tarot Meiga contacte contigo para evaluar tu solicitud. Toda la información será tratada con total confidencialidad.
                </p>

                <button type="submit" style={S.btn} disabled={mutation.isPending}>
                  {mutation.isPending ? "Enviando..." : "✦ Enviar Solicitud"}
                </button>
              </form>
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
