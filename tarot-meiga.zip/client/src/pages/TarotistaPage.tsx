import { useState, useEffect, useRef } from "react";
import { useRoute, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { ArrowLeft, Send, Lock, Star, MessageCircle } from "lucide-react";
import { nanoid } from "nanoid";

const LOGO_URL = "https://files.manuscdn.com/user_upload_by_module/session_file/310519663356619570/dsLtSRVAHZMAsXew.png";

function getSessionId(): string {
  let id = localStorage.getItem("tarot_session_id");
  if (!id) {
    id = nanoid();
    localStorage.setItem("tarot_session_id", id);
  }
  return id;
}

function hasUsedFreeQuestion(tarotistId: string): boolean {
  const used = localStorage.getItem(`tarot_used_${tarotistId}`);
  return used === "true";
}

function markFreeQuestionUsed(tarotistId: string): void {
  localStorage.setItem(`tarot_used_${tarotistId}`, "true");
}

interface Message {
  role: "user" | "assistant";
  content: string;
}

export default function TarotistaPage() {
  const [, params] = useRoute("/tarotista/:id");
  const id = params?.id ?? "";

  const { data: tarotista, isLoading } = trpc.tarotistas.getById.useQuery({ id }, { enabled: !!id });

  const [pregunta, setPregunta] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [usedFree, setUsedFree] = useState(false);
  const [sessionId] = useState(() => getSessionId());
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const chatMutation = trpc.chat.preguntar.useMutation({
    onSuccess: (data) => {
      setMessages(prev => [...prev, { role: "assistant", content: data.respuesta }]);
      markFreeQuestionUsed(id);
      setUsedFree(true);
    },
    onError: () => {
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "Las cartas no pueden hablar en este momento. Por favor, inténtalo de nuevo más tarde."
      }]);
    },
  });

  useEffect(() => {
    if (id) setUsedFree(hasUsedFreeQuestion(id));
  }, [id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pregunta.trim() || usedFree || chatMutation.isPending) return;

    const userMsg = pregunta.trim();
    setMessages(prev => [...prev, { role: "user", content: userMsg }]);
    setPregunta("");

    chatMutation.mutate({
      tarotistId: id,
      pregunta: userMsg,
      sessionId,
    });
  };

  if (isLoading) {
    return (
      <div style={{ minHeight: "100vh", background: "oklch(0.10 0.02 280)" }}>
        <Header />
        <div style={{ textAlign: "center", padding: "8rem 2rem", color: "oklch(0.65 0.06 60)" }}>
          <div style={{ fontSize: "4rem", marginBottom: "1rem" }}>🔮</div>
          <p style={{ fontFamily: "'Cinzel', serif", fontSize: "1.1rem" }}>Invocando a la tarotista...</p>
        </div>
      </div>
    );
  }

  if (!tarotista) {
    return (
      <div style={{ minHeight: "100vh", background: "oklch(0.10 0.02 280)" }}>
        <Header />
        <div style={{ textAlign: "center", padding: "8rem 2rem" }}>
          <p style={{ color: "oklch(0.65 0.06 60)", fontFamily: "'Cinzel', serif" }}>Tarotista no encontrada.</p>
          <Link href="/" className="btn-gold" style={{ marginTop: "1rem", display: "inline-block" }}>Volver al inicio</Link>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "oklch(0.10 0.02 280)" }}>
      <Header />

      <div className="container" style={{ padding: "2rem 1rem 4rem" }}>
        {/* Breadcrumb */}
        <Link
          href="/"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "0.5rem",
            color: "oklch(0.65 0.06 60)",
            textDecoration: "none",
            fontSize: "0.85rem",
            fontFamily: "'Cinzel', serif",
            marginBottom: "2rem",
            transition: "color 0.2s ease",
          }}
          onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = "oklch(0.72 0.15 65)")}
          onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = "oklch(0.65 0.06 60)")}
        >
          <ArrowLeft size={16} />
          Volver a Tarotistas
        </Link>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: "2rem", alignItems: "start" }}>
          {/* Panel izquierdo: perfil */}
          <div>
            <div className="card-mystic" style={{ padding: "2rem", textAlign: "center" }}>
              {/* Línea de color */}
              <div style={{
                position: "absolute", top: 0, left: 0, right: 0, height: "3px",
                background: `linear-gradient(90deg, transparent, ${tarotista.color}, transparent)`,
                borderRadius: "1rem 1rem 0 0",
              }} />

              <div style={{ width: "140px", height: "160px", margin: "0 auto 1rem", borderRadius: "0.75rem", overflow: "hidden", border: `2px solid ${tarotista.color}40` }}>
                <img
                  src={tarotista.imagen || ""}
                  alt={tarotista.nombre}
                  style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center top", display: "block" }}
                  onError={(e) => {
                    const el = e.currentTarget;
                    el.style.display = "none";
                    const parent = el.parentElement;
                    if (parent) {
                      parent.style.display = "flex";
                      parent.style.alignItems = "center";
                      parent.style.justifyContent = "center";
                      parent.style.fontSize = "4rem";
                      parent.style.background = "oklch(0.15 0.04 280)";
                      parent.textContent = tarotista.avatar;
                    }
                  }}
                />
              </div>

              <h1
                className="gradient-gold"
                style={{ fontSize: "1.8rem", fontWeight: "700", fontFamily: "'Cinzel', serif", marginBottom: "0.25rem" }}
              >
                {tarotista.nombre}
              </h1>

              <p style={{ color: "oklch(0.72 0.15 65)", fontSize: "0.85rem", fontFamily: "'Cinzel', serif", letterSpacing: "0.05em", marginBottom: "1.25rem" }}>
                {tarotista.especialidad}
              </p>

              <hr className="divider-gold" style={{ margin: "1rem 0" }} />

              <p style={{ color: "oklch(0.75 0.05 60)", lineHeight: 1.8, fontFamily: "Georgia, serif", fontSize: "0.9rem", textAlign: "left" }}>
                {tarotista.descripcionLarga}
              </p>

              <hr className="divider-gold" style={{ margin: "1rem 0" }} />

              {/* Tags */}
              <div style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem", justifyContent: "center" }}>
                {tarotista.tags.map(tag => (
                  <span key={tag} className="badge-especialidad">{tag}</span>
                ))}
              </div>

              <hr className="divider-gold" style={{ margin: "1rem 0" }} />

              {/* Estado pregunta */}
              <div style={{
                padding: "0.75rem",
                borderRadius: "0.5rem",
                background: usedFree
                  ? "oklch(0.18 0.04 285)"
                  : "linear-gradient(135deg, oklch(0.65 0.18 55 / 0.15), oklch(0.72 0.15 65 / 0.15))",
                border: `1px solid ${usedFree ? "oklch(0.35 0.08 285)" : "oklch(0.72 0.15 65 / 0.4)"}`,
              }}>
                {usedFree ? (
                  <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", justifyContent: "center" }}>
                    <Lock size={14} style={{ color: "oklch(0.55 0.06 60)" }} />
                    <span style={{ color: "oklch(0.55 0.06 60)", fontSize: "0.8rem", fontFamily: "'Cinzel', serif" }}>
                      Pregunta gratuita utilizada
                    </span>
                  </div>
                ) : (
                  <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", justifyContent: "center" }}>
                    <Star size={14} style={{ color: "oklch(0.72 0.15 65)" }} />
                    <span style={{ color: "oklch(0.85 0.12 65)", fontSize: "0.8rem", fontFamily: "'Cinzel', serif" }}>
                      1 Pregunta Gratuita disponible
                    </span>
                  </div>
                )}
              </div>

              {usedFree && (
                <div style={{ marginTop: "1rem" }}>
                  <p style={{ color: "oklch(0.60 0.04 60)", fontSize: "0.8rem", fontFamily: "Georgia, serif", marginBottom: "0.75rem" }}>
                    ¿Quieres más respuestas? Reserva una consulta con Reina.
                  </p>
                  <Link href="/reservar" className="btn-gold" style={{ padding: "0.6rem 1.25rem", fontSize: "0.75rem" }}>
                    Reservar con Reina
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* Panel derecho: chat */}
          <div>
            <div
              className="card-mystic"
              style={{ padding: "0", overflow: "hidden", display: "flex", flexDirection: "column", minHeight: "500px" }}
            >
              {/* Header del chat */}
              <div style={{
                padding: "1.25rem 1.5rem",
                borderBottom: "1px solid oklch(0.28 0.06 285)",
                background: "linear-gradient(90deg, oklch(0.14 0.04 285), oklch(0.16 0.05 290))",
                display: "flex",
                alignItems: "center",
                gap: "0.75rem",
              }}>
                <div style={{ fontSize: "1.8rem" }}>{tarotista.avatar}</div>
                <div>
                  <div style={{ color: "oklch(0.92 0.04 60)", fontFamily: "'Cinzel', serif", fontWeight: "600", fontSize: "0.95rem" }}>
                    {tarotista.nombre}
                  </div>
                  <div style={{ color: "oklch(0.65 0.06 60)", fontSize: "0.75rem", fontFamily: "Georgia, serif" }}>
                    {usedFree ? "Consulta finalizada" : "Lista para responder tu pregunta"}
                  </div>
                </div>
                <div style={{ marginLeft: "auto" }}>
                  <div style={{
                    width: "8px", height: "8px", borderRadius: "50%",
                    background: usedFree ? "oklch(0.55 0.06 60)" : "oklch(0.60 0.20 145)",
                    boxShadow: usedFree ? "none" : "0 0 6px oklch(0.60 0.20 145)",
                  }} />
                </div>
              </div>

              {/* Mensajes */}
              <div style={{
                flex: 1,
                padding: "1.5rem",
                overflowY: "auto",
                display: "flex",
                flexDirection: "column",
                gap: "1rem",
                minHeight: "300px",
                maxHeight: "400px",
              }}>
                {messages.length === 0 && (
                  <div style={{ textAlign: "center", padding: "3rem 1rem", color: "oklch(0.50 0.04 60)" }}>
                    <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>{tarotista.avatar}</div>
                    <p style={{ fontFamily: "'Cinzel', serif", fontSize: "0.9rem", color: "oklch(0.65 0.06 60)", marginBottom: "0.5rem" }}>
                      {tarotista.nombre} está lista para ti
                    </p>
                    <p style={{ fontFamily: "Georgia, serif", fontSize: "0.8rem", lineHeight: 1.6 }}>
                      {usedFree
                        ? "Ya has utilizado tu pregunta gratuita con esta tarotista."
                        : "Escribe tu pregunta y las cartas revelarán su mensaje."}
                    </p>
                  </div>
                )}

                {messages.map((msg, i) => (
                  <div
                    key={i}
                    style={{
                      display: "flex",
                      justifyContent: msg.role === "user" ? "flex-end" : "flex-start",
                      gap: "0.5rem",
                      alignItems: "flex-start",
                    }}
                  >
                    {msg.role === "assistant" && (
                      <div style={{
                        width: "32px", height: "32px", borderRadius: "50%",
                        background: "linear-gradient(135deg, oklch(0.20 0.06 285), oklch(0.28 0.08 290))",
                        border: "1px solid oklch(0.72 0.15 65 / 0.4)",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: "1rem", flexShrink: 0,
                      }}>
                        {tarotista.avatar}
                      </div>
                    )}
                    <div
                      style={{
                        maxWidth: "80%",
                        padding: "0.75rem 1rem",
                        borderRadius: msg.role === "user" ? "1rem 1rem 0 1rem" : "1rem 1rem 1rem 0",
                        background: msg.role === "user"
                          ? "linear-gradient(135deg, oklch(0.65 0.18 55 / 0.3), oklch(0.72 0.15 65 / 0.3))"
                          : "oklch(0.18 0.04 285)",
                        border: msg.role === "user"
                          ? "1px solid oklch(0.72 0.15 65 / 0.4)"
                          : "1px solid oklch(0.28 0.06 285)",
                        color: "oklch(0.88 0.04 60)",
                        fontSize: "0.88rem",
                        lineHeight: 1.7,
                        fontFamily: "Georgia, serif",
                      }}
                    >
                      {msg.content}
                    </div>
                    {msg.role === "user" && (
                      <div style={{
                        width: "32px", height: "32px", borderRadius: "50%",
                        background: "linear-gradient(135deg, oklch(0.65 0.18 55 / 0.3), oklch(0.72 0.15 65 / 0.3))",
                        border: "1px solid oklch(0.72 0.15 65 / 0.4)",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: "0.9rem", flexShrink: 0,
                      }}>
                        👤
                      </div>
                    )}
                  </div>
                ))}

                {chatMutation.isPending && (
                  <div style={{ display: "flex", gap: "0.5rem", alignItems: "flex-start" }}>
                    <div style={{
                      width: "32px", height: "32px", borderRadius: "50%",
                      background: "linear-gradient(135deg, oklch(0.20 0.06 285), oklch(0.28 0.08 290))",
                      border: "1px solid oklch(0.72 0.15 65 / 0.4)",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: "1rem", flexShrink: 0,
                    }}>
                      {tarotista.avatar}
                    </div>
                    <div style={{
                      padding: "0.75rem 1rem",
                      borderRadius: "1rem 1rem 1rem 0",
                      background: "oklch(0.18 0.04 285)",
                      border: "1px solid oklch(0.28 0.06 285)",
                    }}>
                      <div style={{ display: "flex", gap: "4px", alignItems: "center" }}>
                        {[0, 1, 2].map(i => (
                          <div key={i} style={{
                            width: "6px", height: "6px", borderRadius: "50%",
                            background: "oklch(0.72 0.15 65)",
                            animation: `pulse 1.4s ease-in-out ${i * 0.2}s infinite`,
                          }} />
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>

              {/* Input del chat */}
              <div style={{
                padding: "1rem 1.5rem",
                borderTop: "1px solid oklch(0.28 0.06 285)",
                background: "oklch(0.12 0.03 280)",
              }}>
                {usedFree ? (
                  <div style={{ textAlign: "center", padding: "0.5rem" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", justifyContent: "center", marginBottom: "0.75rem" }}>
                      <Lock size={14} style={{ color: "oklch(0.55 0.06 60)" }} />
                      <span style={{ color: "oklch(0.55 0.06 60)", fontSize: "0.8rem", fontFamily: "'Cinzel', serif" }}>
                        Has utilizado tu pregunta gratuita
                      </span>
                    </div>
                    <Link href="/reservar" className="btn-gold" style={{ padding: "0.6rem 1.5rem", fontSize: "0.75rem" }}>
                      Reservar Consulta Completa con Reina
                    </Link>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} style={{ display: "flex", gap: "0.75rem" }}>
                    <input
                      type="text"
                      value={pregunta}
                      onChange={(e) => setPregunta(e.target.value)}
                      placeholder={`Escribe tu pregunta para ${tarotista.nombre}...`}
                      disabled={chatMutation.isPending}
                      className="input-mystic"
                      style={{ flex: 1 }}
                    />
                    <button
                      type="submit"
                      disabled={!pregunta.trim() || chatMutation.isPending}
                      style={{
                        background: "linear-gradient(135deg, oklch(0.65 0.18 55), oklch(0.72 0.15 65))",
                        border: "none",
                        borderRadius: "0.5rem",
                        padding: "0.75rem 1rem",
                        color: "oklch(0.10 0.02 280)",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        opacity: (!pregunta.trim() || chatMutation.isPending) ? 0.5 : 1,
                        transition: "all 0.2s ease",
                        flexShrink: 0,
                      }}
                    >
                      <Send size={16} />
                    </button>
                  </form>
                )}
                {!usedFree && (
                  <p style={{ color: "oklch(0.45 0.04 60)", fontSize: "0.72rem", textAlign: "center", marginTop: "0.5rem", fontFamily: "Georgia, serif" }}>
                    <MessageCircle size={10} style={{ display: "inline", marginRight: "0.25rem" }} />
                    Tienes 1 pregunta gratuita con {tarotista.nombre}
                  </p>
                )}
              </div>
            </div>

            {/* CTA Reina */}
            <div
              className="card-mystic"
              style={{ padding: "1.5rem", marginTop: "1.25rem", textAlign: "center" }}
            >
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: "linear-gradient(90deg, transparent, oklch(0.72 0.15 65), transparent)", borderRadius: "1rem 1rem 0 0" }} />
              <img
                src={LOGO_URL}
                alt="Reina"
                style={{ width: "50px", height: "50px", objectFit: "contain", margin: "0 auto 0.75rem" }}
              />
              <h3 style={{ color: "oklch(0.85 0.12 65)", fontFamily: "'Cinzel', serif", fontSize: "1rem", marginBottom: "0.5rem" }}>
                ¿Quieres una lectura más profunda?
              </h3>
              <p style={{ color: "oklch(0.65 0.04 60)", fontSize: "0.82rem", fontFamily: "Georgia, serif", marginBottom: "1rem", lineHeight: 1.6 }}>
                Reserva una consulta personal con <strong style={{ color: "oklch(0.85 0.12 65)" }}>Reina</strong>,
                nuestra tarotista humana con más de 20 años de experiencia.
              </p>
              <Link href="/reservar" className="btn-gold" style={{ padding: "0.6rem 1.5rem", fontSize: "0.75rem" }}>
                Reservar con Reina
              </Link>
            </div>
          </div>
        </div>
      </div>

      <Footer />

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.3; transform: scale(0.8); }
          50% { opacity: 1; transform: scale(1.2); }
        }
      `}</style>
    </div>
  );
}
